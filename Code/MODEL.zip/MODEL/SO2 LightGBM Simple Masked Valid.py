# ===== SO2 LightGBM Simple Masked Validation =====
"""
SO2 LightGBM Simple Masked Validation

中文/English 双语说明 / Bilingual guide

在 2023 年测试集上验证 LightGBM 的缺测填补能力，支持：
- 随机样本遮挡（Masked Validation）
- 可选屏蔽敏感特征（如 neighbor/lag1）
- 指标包括 RMSE/MAE/R²/相关/偏差/NRMSE

Validate a LightGBM gap-filling model on 2023 data with:
- Random masked samples
- Optional sensitive feature masking (e.g., neighbor/lag1)
- Metrics: RMSE/MAE/R²/Correlation/Bias/NRMSE
"""

import os
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

def compute_core_metrics(y_true, y_pred):
    """
    [Step 1 / 步骤1] 计算核心评估指标 / Compute core metrics
    - RMSE / MAE / R² / 相关系数 / 偏差 / NRMSE(std, range)
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    
    # 移除NaN值
    valid_mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if np.sum(valid_mask) == 0:
        return None
    
    y_true = y_true[valid_mask]
    y_pred = y_pred[valid_mask]
    
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # 计算NRMSE
    std_true = np.std(y_true)
    range_true = np.max(y_true) - np.min(y_true)
    nrmse_std = rmse / std_true if std_true > 0 else np.nan
    nrmse_range = rmse / range_true if range_true > 0 else np.nan
    
    # 计算相关系数和偏差
    corr = np.corrcoef(y_true, y_pred)[0, 1] if len(y_true) > 1 else 0
    bias = np.mean(y_pred - y_true)
    
    return {
        'rmse': rmse,
        'nrmse_std': nrmse_std,
        'nrmse_range': nrmse_range,
        'mae': mae,
        'r2': r2,
        'corr': corr,
        'bias': bias,
        'n_valid': len(y_true)
    }

def print_compact_metrics(title, metrics, n_samples):
    """
    [Step 2 / 步骤2] 紧凑打印指标摘要 / Compact metric summary printer
    """
    if metrics is None:
        print(f"{title} | n=0 | No valid samples")
        return
    
    print(f"{title} | n={n_samples:,} | "
          f"RMSE={metrics['rmse']:.6f} | "
          f"NRMSE_std={metrics['nrmse_std']:.4f} | "
          f"NRMSE_range={metrics['nrmse_range']:.4f} | "
          f"MAE={metrics['mae']:.6f} | "
          f"R²={metrics['r2']:.4f} | "
          f"Corr={metrics['corr']:.4f} | "
          f"Bias={metrics['bias']:.6f}")

class SO2LightGBMMaskedValidator:
    """
    [Step 3 / 步骤3] SO2 LightGBM 遮挡验证器

    - 加载训练好的 LightGBM 模型与标准化器
    - 加载 2023 数据（扁平化像素为样本）
    - 应用标准化与敏感特征遮挡，进行预测与评估
    """
    def __init__(self, base_path="/content/drive/MyDrive"):
        self.base_path = base_path
        self.test_year = 2023
        self.test_dir = os.path.join(base_path, "Feature_Stacks", f"SO2_{self.test_year}")
        
        # 模型和标准化器路径
        self.model_path = "/content/drive/MyDrive/Models/SO2_LightGBM_GapFilling/so2_lightgbm_gapfilling_model.txt"
        self.scaler_path = "/content/drive/MyDrive/3DCNN_Pipeline/artifacts/scalers/SO2/meanstd_global_2019_2021.npz"
        
        # 特征配置
        self.continuous_features = [
            'dem', 'slope', 'population', 'u10', 'v10', 'blh', 'tp', 't2m', 'sp', 'str', 'ssr', 'ws',
            'lag1', 'neighbor', 'so2_climate_prior'
        ]
        self.categorical_features = [f'lulc_{i+1:02d}' for i in range(10)]
        self.non_standardized = ['wd_sin', 'wd_cos', 'sin_doy', 'cos_doy', 'weekday_weight']
        
        # 特征名称映射 - 修复映射关系
        self.feature_name_map = {
            'pop': 'population',
            'ssr_clear': 'ssr',
            'so2_lag1': 'lag1',
            'so2_neighbor': 'neighbor'
        }
        # 修复lulc特征映射：lulc_class_10 -> lulc_01, lulc_class_20 -> lulc_02, etc.
        for i in range(10):
            self.feature_name_map[f'lulc_class_{10*(i+1)}'] = f'lulc_{i+1:02d}'
        
        self.model = None
        self.scalers = None
        self.feature_order = None
        
    def load_model_and_scaler(self):
        """
        [Step 4 / 步骤4] 加载 LightGBM 模型与 SO2 标准化器
        Load trained model and scaler (aligned to SO2 training).
        """
        print("📊 Loading trained model and scaler...")
        
        # 加载模型
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model file not found: {self.model_path}")
        self.model = lgb.Booster(model_file=self.model_path)
        print(f"✅ Model loaded from: {self.model_path}")
        
        # 加载标准化器 - 匹配训练代码的逻辑
        if not os.path.exists(self.scaler_path):
            raise FileNotFoundError(f"Scaler file not found: {self.scaler_path}")
        
        print(f"📊 Loading scaler from: {self.scaler_path}")
        with np.load(self.scaler_path, allow_pickle=True) as data:
            if 'channel_list' in data and 'mean' in data and 'std' in data:
                self.feature_order = data['channel_list'].tolist()
                
                self.scalers = {}
                mean_dict = data['mean'].item() if isinstance(data['mean'], np.ndarray) and data['mean'].ndim == 0 else data['mean']
                std_dict = data['std'].item() if isinstance(data['std'], np.ndarray) and data['std'].ndim == 0 else data['std']
                
                for feat_name in self.feature_order:
                    if feat_name in mean_dict and feat_name in std_dict and mean_dict[feat_name] is not None and std_dict[feat_name] is not None:
                        self.scalers[feat_name] = {
                            'mean': mean_dict[feat_name],
                            'std': std_dict[feat_name],
                            'is_constant': std_dict[feat_name] <= 1e-8
                        }
                    elif feat_name in data['noscale'].tolist():
                        self.scalers[feat_name] = {'is_constant': True}
                    else:
                        print(f"   ⚠️ Scaler data missing for feature: {feat_name}. Using default mean=0, std=1.")
                        self.scalers[feat_name] = {
                            'mean': 0.0,
                            'std': 1.0,
                            'is_constant': False
                        }
                
                metadata = {
                    'method': data['method'].item() if 'method' in data else 'unknown',
                    'mode': data['mode'].item() if 'mode' in data else 'unknown',
                    'pollutant': data['pollutant'].item() if 'pollutant' in data else 'unknown',
                    'train_years': data['train_years'].tolist() if 'train_years' in data else [],
                    'noscale': data['noscale'].tolist() if 'noscale' in data else []
                }
                print(f"✅ Scaler loaded: {metadata.get('mode', 'unknown')} mode, {metadata.get('pollutant', 'unknown')} for years {metadata.get('train_years', [])}")
                print(f"   Loaded {len(self.feature_order)} features from scaler.")
                print(f"   Non-scaled features: {metadata.get('noscale', [])}")
                print(f"   Feature mapping: {self.feature_name_map}")
            else:
                raise ValueError("Scaler file structure mismatch. Expected 'channel_list', 'mean', 'std' keys.")
        
        return True
    
    def apply_scaler(self, X, feature_names):
        """
        [Step 5 / 步骤5] 应用标准化：对每个特征按 mean/std 标准化
        Apply per-feature standardization using scaler.
        """
        Xs = X.copy()
        
        for i, name in enumerate(feature_names):
            if name in self.scalers:
                scaler_info = self.scalers[name]
                if not scaler_info.get('is_constant', False) and 'mean' in scaler_info and 'std' in scaler_info:
                    mean = scaler_info['mean']
                    std = scaler_info['std']
                    if std > 1e-8:
                        Xs[:, i] = (X[:, i] - mean) / std
                    else:
                        Xs[:, i] = np.where(np.isfinite(X[:, i]), 0.0, np.nan)
                elif name in self.non_standardized:
                    pass
                else:
                    Xs[:, i] = np.where(np.isfinite(X[:, i]), 0.0, np.nan)
        
        return Xs
    
    def load_test_data(self, max_files=50):
        """
        [Step 6 / 步骤6] 加载 2023 测试数据并扁平化为样本
        Load 2023 test stacks and flatten into per-pixel samples.
        """
        print(f"📊 Loading 2023 test data (max {max_files} files)...")
        
        if not os.path.exists(self.test_dir):
            raise FileNotFoundError(f"Test directory not found: {self.test_dir}")
        
        test_files = sorted([f for f in os.listdir(self.test_dir) 
                           if f.startswith("SO2_stack_") and f.endswith('.npz')])
        
        if max_files:
            test_files = test_files[:max_files]
        
        print(f"📁 Found {len(test_files)} test files")
        
        # 先检查数据可用性
        print("🔍 Checking data availability...")
        valid_files_count = 0
        for i, filename in enumerate(test_files[:10]):  # 检查前10个文件
            try:
                file_path = os.path.join(self.test_dir, filename)
                with np.load(file_path, allow_pickle=True, mmap_mode='r') as data:
                    if 'y' in data and 'mask' in data:
                        y = data['y']
                        if isinstance(y, np.ndarray) and y.dtype.kind in 'fi':
                            for s in (-9999, -32768):
                                y = np.where(y == s, np.nan, y)
                            y = np.where(np.abs(y) > 1e6, np.nan, y)
                        
                        valid_mask = np.isfinite(y) & (y > 0)
                        valid_count = np.sum(valid_mask)
                        if valid_count > 0:
                            valid_files_count += 1
                            print(f"   ✅ {filename}: {valid_count:,} valid SO2 observations")
                        else:
                            print(f"   ❌ {filename}: No valid SO2 observations")
            except Exception as e:
                print(f"   ⚠️ {filename}: Error - {e}")
        
        print(f"📊 Data availability: {valid_files_count}/10 files have valid SO2 data")
        if valid_files_count == 0:
            print("⚠️ No valid SO2 data found in first 10 files. Trying more files...")
        
        X_list, y_list = [], []
        processed_count = 0
        skipped_low_valid_ratio = 0
        skipped_no_target_mask = 0
        skipped_error = 0
        
        for i, filename in enumerate(test_files):
            try:
                file_path = os.path.join(self.test_dir, filename)
                with np.load(file_path, allow_pickle=True, mmap_mode='r') as data:
                    # 检查必要的数据键
                    if 'y' not in data or 'mask' not in data:
                        skipped_no_target_mask += 1
                        if i < 10 or (i+1) % 100 == 0:
                            print(f"   ⚠️ {filename}: Missing y or mask, skipped.")
                        continue
                    
                    y = data['y']
                    mask = data['mask']
                    
                    # 数据清理 - 匹配训练代码
                    if isinstance(y, np.ndarray) and y.dtype.kind in 'fi':
                        for s in (-9999, -32768):
                            y = np.where(y == s, np.nan, y)
                        y = np.where(np.abs(y) > 1e6, np.nan, y)
                    
                    # 构建特征矩阵 - 匹配训练代码的逻辑
                    # [Step 6.1 / 步骤6.1] 基于 scaler 顺序与映射组装特征
                    X_features_for_this_file = []
                    
                    # 检查是否有X数组和feature_names
                    if 'X' in data and 'feature_names' in data:
                        X_array = data['X']  # (30, H, W)
                        feature_names = data['feature_names']  # 30个特征名
                        
                        # 确保feature_names是列表格式
                        if isinstance(feature_names, np.ndarray):
                            feature_names = feature_names.tolist()
                        
                        # 根据标准化器的feature_order重新排列
                        for scaler_feat_name in self.feature_order:
                            # 首先尝试直接匹配
                            if scaler_feat_name in feature_names:
                                idx = feature_names.index(scaler_feat_name)
                                X_features_for_this_file.append(X_array[idx])
                            else:
                                # 尝试通过映射找到对应的特征
                                found = False
                                for stack_name, scaler_name in self.feature_name_map.items():
                                    if scaler_name == scaler_feat_name and stack_name in feature_names:
                                        idx = feature_names.index(stack_name)
                                        X_features_for_this_file.append(X_array[idx])
                                        found = True
                                        break
                                
                                if not found:
                                    # 如果特征不存在，用NaN填充
                                    X_features_for_this_file.append(np.full(y.shape, np.nan, dtype=np.float32))
                    else:
                        # 回退到原来的逻辑（如果X数组不存在）
                        for scaler_feat_name in self.feature_order:
                            data_feat_name = None
                            for data_key, scaler_key in self.feature_name_map.items():
                                if scaler_key == scaler_feat_name:
                                    data_feat_name = data_key
                                    break
                            
                            if data_feat_name is None:
                                data_feat_name = scaler_feat_name
                            
                            if data_feat_name in data:
                                X_features_for_this_file.append(data[data_feat_name])
                            else:
                                X_features_for_this_file.append(np.full(y.shape, np.nan, dtype=np.float32))
                    
                    if not X_features_for_this_file:
                        print(f"   ⚠️ No features could be processed for {filename} after mapping, skipping.")
                        continue
                    
                    X_final = np.stack(X_features_for_this_file, axis=0)
                    
                    # 展平并选择所有像素（匹配训练代码的predict_mask逻辑）
                    # [Step 6.2 / 步骤6.2] 扁平化像素 -> 样本
                    X_flat = X_final.reshape(X_final.shape[0], -1).T
                    y_flat = y.flatten()
                    predict_flat = np.ones_like(y_flat, dtype=bool)  # 预测所有像素
                    
                    idx = np.where(predict_flat)[0]
                    if len(idx) == 0:
                        skipped_low_valid_ratio += 1
                        if i < 10 or (i+1) % 100 == 0:
                            print(f"   ⚠️ {filename}: No pixels to predict after flattening, skipped.")
                        continue
                    
                    # 处理缺失特征
                    # [Step 6.3 / 步骤6.3] 缺失值填补（均值或零）
                    X_predict = X_flat[idx]
                    for j in range(X_predict.shape[1]):
                        col_data = X_predict[:, j]
                        if np.any(np.isfinite(col_data)):
                            mean_val = np.nanmean(col_data)
                            X_predict[:, j] = np.where(np.isfinite(col_data), col_data, mean_val)
                        else:
                            X_predict[:, j] = 0.0
                    
                    # 关键修改：使用所有像素进行训练，但只对有SO2观测的像素提供标签
                    y_predict = y_flat[idx]
                    valid_y_mask = np.isfinite(y_predict)
                    
                    # SO2过滤y<=0 - 匹配训练代码
                    valid_y_mask &= (y_predict > 0)
                    
                    # 检查是否有足够的有效SO2观测作为训练标签 - 降低阈值
                    if np.sum(valid_y_mask) < 10:  # 降低阈值，允许更多文件参与验证
                        skipped_low_valid_ratio += 1
                        if i < 10 or (i+1) % 100 == 0:
                            print(f"   ⚠️ {filename}: Too few valid SO2 observations ({np.sum(valid_y_mask)}), skipped.")
                        continue
                    
                    # 只使用有SO2观测的像素进行验证
                    # [Step 6.4 / 步骤6.4] 仅用有观测的像素计算指标
                    valid_indices = np.where(valid_y_mask)[0]
                    X_valid = X_predict[valid_indices]
                    y_valid = y_predict[valid_indices]
                    
                    X_list.append(X_valid)
                    y_list.append(y_valid)
                    processed_count += 1
                    
                    if (i+1) % 10 == 0:
                        print(f"   📊 Processed {i+1}/{len(test_files)} files. Current valid samples: {sum(len(x) for x in X_list):,}")
            
            except Exception as e:
                skipped_error += 1
                print(f"   ⚠️ Error processing {filename}: {e}")
                continue
        
        print(f"   Summary: Processed {processed_count} files. Skipped {skipped_no_target_mask} (missing target/mask), {skipped_low_valid_ratio} (low valid ratio), {skipped_error} (errors).")
        
        if len(X_list) == 0:
            raise ValueError("No valid test data found")
        
        X_test = np.vstack(X_list)
        y_test = np.hstack(y_list)
        
        print(f"✅ Loaded {len(X_test):,} test samples from {processed_count} files")
        return X_test, y_test
    
    def create_masked_data(self, X, y, mask_ratio=0.2, mask_sensitive=True):
        """
        [Step 7 / 步骤7] 创建遮挡样本（可选屏蔽敏感特征）
        Create masked subset and optionally zero-out sensitive features.
        """
        n_samples = len(y)
        n_mask = int(n_samples * mask_ratio)
        
        # 随机选择要遮挡的样本
        np.random.seed(42)
        mask_indices = np.random.choice(n_samples, n_mask, replace=False)
        
        # 创建遮挡后的特征
        X_masked = X.copy()
        
        if mask_sensitive:
            # 找到敏感特征的索引
            sensitive_features = ['neighbor', 'lag1']
            for feat_name in sensitive_features:
                if feat_name in self.feature_order:
                    feat_idx = self.feature_order.index(feat_name)
                    # 在遮挡区域将敏感特征设为NaN
                    X_masked[mask_indices, feat_idx] = np.nan
        
        # 创建真实标签（只用于被遮挡的像素）
        y_masked = y[mask_indices]
        
        return X_masked, y_masked, mask_indices
    
    def run_masked_validation(self, max_files=50, mask_ratio=0.2, mask_sensitive=True):
        """
        [Step 8 / 步骤8] 运行遮挡验证：加载 -> 标准化 -> 遮挡 -> 预测 -> 评估
        Run masked validation pipeline end-to-end.
        """
        print("🚀 SO2 LightGBM Masked Validation")
        print(f"   - Test year: {self.test_year}")
        print(f"   - Mask ratio: {mask_ratio:.1%}")
        print(f"   - Mask sensitive features: {mask_sensitive}")
        
        # 加载模型和标准化器
        self.load_model_and_scaler()
        
        # 加载测试数据
        X_test, y_test = self.load_test_data(max_files=max_files)
        
        # 应用标准化器
        # [Step 8.1 / 步骤8.1] 标准化测试样本
        X_test_scaled = self.apply_scaler(X_test, self.feature_order)
        
        # 创建遮挡数据
        # [Step 8.2 / 步骤8.2] 生成遮挡样本与索引
        X_masked, y_masked, mask_indices = self.create_masked_data(
            X_test_scaled, y_test, mask_ratio=mask_ratio, mask_sensitive=mask_sensitive
        )
        
        print(f"📊 Created {len(y_masked):,} masked samples")
        
        # 预测被遮挡的像素
        # [Step 8.3 / 步骤8.3] 用模型对被遮挡样本进行预测
        print("🔮 Predicting masked pixels...")
        y_pred = self.model.predict(X_masked[mask_indices])
        
        # 计算指标
        # [Step 8.4 / 步骤8.4] 计算评估指标
        metrics = compute_core_metrics(y_masked, y_pred)
        
        # 打印结果
        print("\n" + "="*80)
        print("📊 SO2 LightGBM Masked Validation Results")
        print("="*80)
        print_compact_metrics("masked_validation", metrics, len(y_masked))
        
        if metrics:
            print(f"\n💡 Interpretation:")
            print(f"   - R² = {metrics['r2']:.4f}: {'Good' if metrics['r2'] > 0.5 else 'Fair' if metrics['r2'] > 0.2 else 'Poor'} gap-filling performance")
            print(f"   - NRMSE_std = {metrics['nrmse_std']:.4f}: {'Good' if metrics['nrmse_std'] < 0.5 else 'Fair' if metrics['nrmse_std'] < 1.0 else 'Poor'} relative to data variability")
            print(f"   - Bias = {metrics['bias']:.6f}: {'Unbiased' if abs(metrics['bias']) < 0.001 else 'Biased'} predictions")
        
        return metrics, y_masked, y_pred

# ===== 运行验证 =====
if __name__ == "__main__":
    # 创建验证器
    validator = SO2LightGBMMaskedValidator()
    
    # 运行简单masked validation
    print("🚀 Starting SO2 LightGBM Masked Validation...")
    
    # 测试不同遮挡比例
    for ratio in [0.1, 0.2, 0.3]:
        print(f"\n{'='*60}")
        print(f"Testing mask ratio: {ratio:.1%}")
        print('='*60)
        
        try:
            metrics, y_true, y_pred = validator.run_masked_validation(
                max_files=100,  # 增加文件数量以找到更多有效数据
                mask_ratio=ratio,
                mask_sensitive=True
            )
        except Exception as e:
            print(f"❌ Error with ratio {ratio:.1%}: {e}")
            continue
    
    print("\n🎉 SO2 LightGBM Masked Validation completed!")
