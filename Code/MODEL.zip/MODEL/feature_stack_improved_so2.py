%%writefile /content/drive/MyDrive/GeoGapFiller/feature_stack_improved_so2.py

import rasterio
import xarray as xr
import numpy as np
import os
import pandas as pd
import re
from datetime import datetime, timedelta
from scipy.ndimage import generic_filter
import warnings
import calendar
import geopandas as gpd
from rasterio.features import rasterize

# Default to built-in PATHS. Optionally allow overriding via config when env USE_CONFIG_PATHS=1
BASE = "/content/drive/MyDrive"
PATHS = {
    # Target observations
    "SO2_DAILY": os.path.join(BASE, "GEE_SO2", "SO2_Daily_Multiband_{year}.tif"),
    # Precomputed parameters
    "SO2_LAG1": os.path.join(BASE, "Variables/so2_lag_1day", "SO2_Lag1day_CAMS_2019_2023.nc"),
    "SO2_NEI": os.path.join(BASE, "Variables", "SO2_Neighbor_Mean_2019_2023.tif"),
    "SO2_CLIMATOLOGY": os.path.join(BASE, "Variables/so2_monthly_climatology", "so2_monthly_climatology_2019_2023.tif"),
    # Day-of-year
    "SIN_DOY": os.path.join(BASE, "Variables/day_of_year", "sin_doy_{year}.tif"),
    "COS_DOY": os.path.join(BASE, "Variables/day_of_year", "cos_doy_{year}.tif"),
    # Weekday weights (SO2 specific if available)
    "WEIGHTS_SO2": os.path.join(BASE, "Variables", "so2_weekday_weight_2019_2023.csv"),
    # Static
    "DEM": os.path.join(BASE, "Variables/dem_aligned_s5p/dem_s5p_aligned.tif"),
    "SLOPE": os.path.join(BASE, "Variables/slope_aligned_s5p/slope_s5p_aligned.tif"),
    "POP": os.path.join(BASE, "Variables/population_aligned_s5p/population_2020_s5p_aligned_fixed.tif"),
    "LULC_DIR": os.path.join(BASE, "Variables/lulc_esa_onehot_s5p"),
    # Meteorology (daily multiband)
    "U10": os.path.join(BASE, "Variables/10m_u_component_of_wind/u10_processed/u10_daily_{year}.tif"),
    "V10": os.path.join(BASE, "Variables/10m_v_component_of_wind/v10_processed/v10_daily_{year}.tif"),
    "BLH": os.path.join(BASE, "Variables/boundary_layer_height/boundary_layer_height_processed/blh_daily_{year}.tif"),
    "TP": os.path.join(BASE, "Variables/total_precipitation/total_precipitation_processed/precipitation_daily_{year}.tif"),
    "T2M": os.path.join(BASE, "Variables/2m_temperature/2m_temperature_processed/temperature_daily_{year}.tif"),
    "SP": os.path.join(BASE, "Variables/surface_pressure/surface_pressure_processed/pressure_daily_{year}.tif"),
    "STR": os.path.join(BASE, "Variables/surface_net_thermal_radiation/thermal_radiation_processed/thermal_radiation_daily_{year}.tif"),
    "SSR_CLR": os.path.join(BASE, "Variables/surface_net_solar_radiation_clearsky/solar_radiation_processed/solar_radiation_daily_{year}.tif"),
    # Means for fallbacks
    "MEAN_U10": os.path.join(BASE, "Variables/10m_u_component_of_wind/u10_processed/u10_5year_mean.tif"),
    "MEAN_V10": os.path.join(BASE, "Variables/10m_v_component_of_wind/v10_processed/v10_5year_mean.tif"),
    # AOI (optional)
    "AOI": os.path.join(BASE, "AOI", "delimitazione_distretto.shp"),
}

try:
    from config import PATHS as _CFG_PATHS  # type: ignore
    import os as _os
    if _os.environ.get('USE_CONFIG_PATHS', '0') == '1':
        PATHS = _CFG_PATHS
except Exception:
    pass

warnings.filterwarnings('ignore')

def nanmedian_filter(data, size=3):
    """3x3 sliding window that ignores NaN values"""
    def nanmedian_func(values):
        valid_values = values[~np.isnan(values)]
        return np.nanmedian(valid_values) if len(valid_values) > 0 else np.nan
    
    return generic_filter(data, nanmedian_func, size=size)

def nanmedian_exclude_center(data):
    """3x3 sliding window that excludes center pixel to prevent data leakage"""
    # Define footprint that excludes center pixel
    FOOTPRINT_EXC_CENTER = np.array([[1,1,1],
                                     [1,0,1],
                                     [1,1,1]], dtype=bool)
    
    def f(vals):
        # Here vals already contains only 8 neighbor values, no center pixel
        vals = vals[~np.isnan(vals)]
        return np.nan if vals.size == 0 else np.nanmedian(vals)
    
    return generic_filter(data, f, footprint=FOOTPRINT_EXC_CENTER, mode='constant', cval=np.nan)

def nanmean_exclude_center(data):
    """3x3 mean excluding center pixel; ignores NaN and avoids boundary leakage"""
    FOOTPRINT_EXC_CENTER = np.array([[1,1,1],
                                     [1,0,1],
                                     [1,1,1]], dtype=bool)
    def f(vals):
        vals = vals[~np.isnan(vals)]
        return np.nan if vals.size == 0 else np.nanmean(vals)
    return generic_filter(data, f, footprint=FOOTPRINT_EXC_CENTER, mode='constant', cval=np.nan)

def fallback_array(value, height=300, width=621):
    """Create fallback array with specified value"""
    return np.full((height, width), value, dtype=np.float32)

def read_raster_band(path: str, band: int = 1, dtype=np.float32) -> np.ndarray:
    """Read a raster band as float array with unified nodata handling.
    - Uses masked read
    - Converts common nodata (e.g., -9999) to NaN
    """
    with rasterio.open(path) as src:
        ma = src.read(band, masked=True)
        # For integer rasters (e.g., uint8), fill with NaN requires float dtype first
        if not np.issubdtype(ma.dtype, np.floating):
            ma = ma.astype(np.float32)
        arr = ma.filled(np.nan).astype(dtype, copy=False)
        # Convert sentinel nodata if present
        arr = np.where(arr <= -9999, np.nan, arr)
        return arr

def _global_band_index(year: int, day: int, start_year: int = 2019) -> int:
    """Compute global band index for multi-year multiband tifs (1-based for rasterio)."""
    idx = 0
    for y in range(start_year, year):
        idx += 366 if calendar.isleap(y) else 365
    return idx + day

def create_single_day_feature_stack_so2(date_str, year, day_of_year, df_weights):
    """Create SO2 feature stack for a single day with winter missingness enhancements"""
    
    # S5P grid dimensions
    target_height, target_width = 300, 621
    
    # Initialize feature stack
    features = {}

    # --- Optional AOI mask (align with NO2) ---
    aoi_mask = None
    aoi_path = PATHS.get("AOI")
    try:
        if aoi_path and os.path.exists(aoi_path):
            gdf = gpd.read_file(aoi_path)
            with rasterio.open(PATHS['DEM']) as ref:
                if gdf.crs != ref.crs:
                    gdf = gdf.to_crs(ref.crs)
                shapes = [(geom, 1) for geom in gdf.geometry if geom is not None]
                aoi_mask = rasterize(
                    shapes,
                    out_shape=(ref.height, ref.width),
                    transform=ref.transform,
                    fill=0,
                    all_touched=True,
                    dtype="uint8",
                ).astype(bool)
    except Exception:
        aoi_mask = None
    
    # --- Load 5-year means for fallback ---
    u10_mean = None
    v10_mean = None
    
    mean_u10_path = PATHS.get("MEAN_U10")
    mean_v10_path = PATHS.get("MEAN_V10")
    
    if mean_u10_path and os.path.exists(mean_u10_path):
        with rasterio.open(mean_u10_path) as src:
            u10_mean = src.read(1).astype(np.float32)
    
    if mean_v10_path and os.path.exists(mean_v10_path):
        with rasterio.open(mean_v10_path) as src:
            v10_mean = src.read(1).astype(np.float32)
    
    # --- 1. Load Static Variables (fill NaN with median) ---
    static_vars = [
        ('dem', PATHS['DEM']),
        ('slope', PATHS['SLOPE']),
        ('population', PATHS['POP'])
    ]
    
    for var_name, file_path in static_vars:
        if os.path.exists(file_path):
            data = read_raster_band(file_path, band=1)
            # Fill NaN with median for static variables
            if np.any(np.isnan(data)):
                median_val = np.nanmedian(data)
                data = np.where(np.isnan(data), median_val, data)
            features[var_name] = data
    
    # --- 2. LULC One-hot (stable sorting & missing class placeholders) ---
    lulc_dir = PATHS['LULC_DIR']
    lulc_classes = ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
    
    # First create 0 placeholders for all classes (even if directory exists)
    for cls in lulc_classes:
        features[f'lulc_class_{cls}'] = fallback_array(0.0)
    
    # Load actual existing LULC files
    if os.path.exists(lulc_dir):
        pattern = re.compile(r'lulc_class_(\d+)_onehot\.tif$')
        all_files = [f for f in os.listdir(lulc_dir) if f.endswith('.tif')]
        matched = [(int(pattern.search(f).group(1)), f) for f in all_files if pattern.search(f)]
        matched.sort(key=lambda x: x[0])
        for cls_id, f in matched:
            fullp = os.path.join(lulc_dir, f)
            features[f'lulc_class_{cls_id}'] = read_raster_band(fullp, band=1)
    
    # Ensure binary 0/1 values
    for k in [f'lulc_class_{c}' for c in lulc_classes]:
        arr = features[k]
        arr = np.where(np.isnan(arr), 0, arr)
        features[k] = (arr > 0.5).astype(np.float32)
    
    # --- 3. Read daily band (if missing) ---
    meteo_vars = [
        ('u10', PATHS['U10'].format(year=year)),
        ('v10', PATHS['V10'].format(year=year)),
        ('blh', PATHS['BLH'].format(year=year)),
        ('tp', PATHS['TP'].format(year=year)),
        ('t2m', PATHS['T2M'].format(year=year)),
        ('sp', PATHS['SP'].format(year=year)),
        ('str', PATHS['STR'].format(year=year)),
        ('ssr_clear', PATHS['SSR_CLR'].format(year=year))
    ]
    
    for var_name, file_path in meteo_vars:
        full_path = file_path
        if os.path.exists(full_path):
            with rasterio.open(full_path) as src:
                if day_of_year <= src.count:
                    ma = src.read(day_of_year, masked=True)
                    if not np.issubdtype(ma.dtype, np.floating):
                        ma = ma.astype(np.float32)
                    features[var_name] = ma.filled(np.nan).astype(np.float32)
    
    # --- 4. Replace during assembly (fallback if key doesn't exist) ---
    if 'u10' not in features:
        features['u10'] = u10_mean if u10_mean is not None else fallback_array(0.0)
    if 'v10' not in features:
        features['v10'] = v10_mean if v10_mean is not None else fallback_array(0.0)
    # Wind derivatives consistent with NO2
    try:
        u10_arr = features['u10']
        v10_arr = features['v10']
        ws = np.sqrt(u10_arr**2 + v10_arr**2).astype(np.float32)
        wd_rad = np.arctan2(-u10_arr, -v10_arr)
        wd_sin = np.sin(wd_rad).astype(np.float32)
        wd_cos = np.cos(wd_rad).astype(np.float32)
    except Exception:
        ws = fallback_array(0.0)
        wd_sin = fallback_array(0.0)
        wd_cos = fallback_array(0.0)
    features['ws'] = ws
    features['wd_sin'] = wd_sin
    features['wd_cos'] = wd_cos
    
    # --- 5. Load SO2 target variable (real data) ---
    so2_target_file = PATHS['SO2_DAILY'].format(year=year)
    if os.path.exists(so2_target_file):
        with rasterio.open(so2_target_file) as src:
            if day_of_year <= src.count:
                y = read_raster_band(so2_target_file, band=day_of_year)
            else:
                y = np.full((target_height, target_width), np.nan, dtype=np.float32)
    else:
        y = np.full((target_height, target_width), np.nan, dtype=np.float32)
    
    # --- 6. Load SO2 lag1 (NetCDF via xarray, select by time = previous day) ---
    lag1_path_tpl = PATHS['SO2_LAG1']
    lag1_path = lag1_path_tpl.format(year=year) if '{year}' in lag1_path_tpl else lag1_path_tpl
    if os.path.exists(lag1_path):
        try:
            with xr.open_dataset(lag1_path) as ds:
                var = 'so2_lag_1day' if 'so2_lag_1day' in ds.data_vars else list(ds.data_vars)[0]
                target_date = datetime(year, 1, 1) + timedelta(days=day_of_year-1)
                t = np.datetime64(target_date.date())
                times = ds['time'].values
                if t in times:
                    so2_lag1_raw = ds[var].sel(time=t).values.astype(np.float32)
                else:
                    # Fallback: median in a small window around t
                    t0 = t - np.timedelta64(1, 'D')
                    t1 = t + np.timedelta64(1, 'D')
                    so2_lag1_raw = ds[var].sel(time=slice(t0, t1)).median('time', skipna=True).values.astype(np.float32)
        except Exception as e:
            print(f"    ⚠️ SO2 lag1 read error: {e}")
            so2_lag1_raw = np.full((target_height, target_width), np.nan, dtype=np.float32)
    else:
        print(f"    ⚠️ SO2 lag1 file not found: {lag1_path}")
        so2_lag1_raw = np.full((target_height, target_width), np.nan, dtype=np.float32)

    # Missing ratio BEFORE imputation
    lag_missing_before = np.isnan(so2_lag1_raw) | (so2_lag1_raw <= 0)
    lag1_fill_ratio = float(lag_missing_before.mean())

    # SO2 lag1 imputation (same robust method as NO2)
    lag = so2_lag1_raw.copy()
    missing = np.isnan(lag) | (lag <= 0)  # Include ≤0 as missing
    
    if np.any(missing):
        # CRITICAL: Create clean data for median calculation
        lag_for_med = lag.copy()
        lag_for_med[missing] = np.nan  # Bad values don't participate in statistics
        lag_med = nanmedian_filter(lag_for_med)
        lag[missing] = lag_med[missing]
        
        # Handle remaining missing values with improved fallback
        still = np.isnan(lag) | (lag <= 0)
        if np.any(still):
            # Try to use valid data from the same day
            vv = lag[~still]
            if vv.size > 0:
                # Use median of valid data from the same day
                glob = np.median(vv)
                lag[still] = glob
            else:
                # If no valid data, use a small positive value instead of 0
                lag[still] = 1e-6  # Small positive value to avoid 0
    
    so2_lag1 = lag.astype(np.float32)
    features['so2_lag1'] = so2_lag1
    
    # --- 7. Load so2_neighbor (strictly from pre-computed TIFF; no runtime calc) ---
    mean_neighbor_file = PATHS['SO2_NEI'].format(year=year)
    with rasterio.open(mean_neighbor_file) as src:
        band = _global_band_index(year, day_of_year, start_year=2019)
        band = max(1, min(band, src.count))
        ma = src.read(band, masked=True)
        nb = ma.filled(np.nan).astype(np.float32)
    features['so2_neighbor'] = nb
    # Compute neighbor fill ratio (NaN proportion) immediately for reporting
    neighbor_fill_ratio = float(np.mean(np.isnan(nb)))
    
    # --- 9. SO2 Enhancement: Monthly climatology (climate prior) ---
    # Accept both 'YYYYMMDD' and 'YYYY-MM-DD'
    if '-' in date_str:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
    else:
        dt = datetime.strptime(date_str, "%Y%m%d")
    month = dt.month
    
    climatology_file = PATHS['SO2_CLIMATOLOGY']
    if os.path.exists(climatology_file):
        with rasterio.open(climatology_file) as src:
            if month <= src.count:
                climate_prior = src.read(month).astype(np.float32)
            else:
                climate_prior = fallback_array(0.0)
        print(f"    ✅ Loaded monthly climatology for month {month}")
    else:
        print(f"    ⚠️ Climatology file not found: {climatology_file}")
        climate_prior = fallback_array(0.0)
    
    features['so2_climate_prior'] = climate_prior
    
    # --- 10. Load time features (use pre-computed day of year files) ---
    sin_doy_file = PATHS['SIN_DOY'].format(year=year)
    cos_doy_file = PATHS['COS_DOY'].format(year=year)
    
    # Always parse date for weekday calculation and doy calculation
    doy = dt.timetuple().tm_yday  # Always calculate doy for return value
    year_len = 366 if (dt.year % 4 == 0 and (dt.year % 100 != 0 or dt.year % 400 == 0)) else 365
    
    if os.path.exists(sin_doy_file) and os.path.exists(cos_doy_file):
        with rasterio.open(sin_doy_file) as src:
            if day_of_year <= src.count:
                ma = src.read(day_of_year, masked=True)
                sin_doy_arr = ma.filled(np.nan).astype(np.float32)
            else:
                sin_doy_arr = np.full((target_height, target_width), np.nan, dtype=np.float32)
        with rasterio.open(cos_doy_file) as src:
            if day_of_year <= src.count:
                ma = src.read(day_of_year, masked=True)
                cos_doy_arr = ma.filled(np.nan).astype(np.float32)
            else:
                cos_doy_arr = np.full((target_height, target_width), np.nan, dtype=np.float32)
        print(f"    ✅ Loaded pre-computed day of year features for {year}")
    else:
        print(f"    ⚠️ Day of year files not found, calculating in real-time")
        # Fallback to real-time calculation
        angle = 2*np.pi * (doy / year_len)
        sin_doy_arr = np.full((target_height, target_width), np.sin(angle), dtype=np.float32)
        cos_doy_arr = np.full((target_height, target_width), np.cos(angle), dtype=np.float32)
    
    features['sin_doy'] = sin_doy_arr
    features['cos_doy'] = cos_doy_arr
    
    # --- 11. Weekday weight table column name compatibility ---
    weekday = dt.weekday()  # 0=Monday, 6=Sunday
    
    date_key = dt.strftime('%Y-%m-%d')  # unify ISO date string
    if {'date', 'weekday_weight'}.issubset(df_weights.columns):
        # Normalize df_weights['date'] to ISO once (robust to mixed formats)
        try:
            dfw = df_weights.copy()
            dfw['date'] = pd.to_datetime(dfw['date'], errors='coerce').dt.strftime('%Y-%m-%d')
        except Exception:
            dfw = df_weights
        # Use date-based lookup (preferred)
        row = dfw[dfw['date'] == date_key]
        w = float(row['weekday_weight'].iloc[0]) if not row.empty else 1.0
    elif {'day_of_week', 'weekday_weight'}.issubset(df_weights.columns):
        # Use day_of_week-based lookup
        # Note: day_of_week in CSV is 1=Monday, 7=Sunday, but dt.weekday() is 0=Monday, 6=Sunday
        csv_weekday = weekday + 1  # Convert to CSV format
        row = df_weights[df_weights['day_of_week'] == csv_weekday]
        w = float(row['weekday_weight'].iloc[0]) if not row.empty else 1.0
    elif {'weekday', 'weight'}.issubset(df_weights.columns):
        # Fallback to weekday/weight format
        row = df_weights[df_weights['weekday'] == weekday]
        w = float(row['weight'].iloc[0]) if not row.empty else 1.0
    else:
        w = 1.0
    
    features['weekday_weight'] = np.full((target_height, target_width), w, dtype=np.float32)
    
    # --- 12. Assemble feature matrix X (strict order) ---
    feature_order = [
        'dem', 'slope', 'population',
        'lulc_class_10', 'lulc_class_20', 'lulc_class_30', 'lulc_class_40', 'lulc_class_50',
        'lulc_class_60', 'lulc_class_70', 'lulc_class_80', 'lulc_class_90', 'lulc_class_100',
        'u10', 'v10', 'ws', 'wd_sin', 'wd_cos', 'blh', 'tp', 't2m', 'sp', 'str', 'ssr_clear',
        'so2_lag1', 'so2_neighbor', 'so2_climate_prior',  # SO2-specific features
        'sin_doy', 'cos_doy', 'weekday_weight'
    ]
    
    # Ensure all features exist with fallback
    for name in feature_order:
        if name not in features:
            if 'lulc_class_' in name:
                features[name] = fallback_array(0.0)
            else:
                features[name] = fallback_array(0.0)
    
    # Apply AOI mask to all 2D spatial features (exclude sin/cos/weekday)
    if aoi_mask is not None:
        spatial_invariant = {'sin_doy', 'cos_doy', 'weekday_weight'}
        for k, v in list(features.items()):
            if isinstance(v, np.ndarray) and v.ndim == 2 and k not in spatial_invariant:
                if k.startswith('lulc_class_'):
                    features[k] = np.where(aoi_mask, v, 0).astype(v.dtype)
                else:
                    features[k] = np.where(aoi_mask, v, np.nan).astype(v.dtype)
        # also mask target
        y = np.where(aoi_mask, y, np.nan)

    # Assemble X with strict order
    X = np.stack([features[name] for name in feature_order], axis=0).astype(np.float32)

    # Quick shape guard for inputs (helps early detect misalignment)
    def _assert_shape(name: str, arr: np.ndarray, h: int = target_height, w: int = target_width):
        if not isinstance(arr, np.ndarray) or arr.shape != (h, w):
            raise ValueError(f"{name} shape {arr.shape} != ({h},{w})")
    for k, v in features.items():
        if isinstance(v, np.ndarray) and v.ndim == 2:
            _assert_shape(k, v)
    
    # --- 13. Create mask (1=valid, 0=invalid) to align with NO2 ---
    mask = (np.isfinite(y) & (y > 0)).astype(np.uint8)
    
    # --- 14. Calculate coverage and trainable status ---
    valid_pixels = int(mask.sum())
    total_pixels = int(mask.size)
    coverage = valid_pixels / total_pixels if total_pixels > 0 else 0.0
    # For SO2, coverage is typically much lower than NO2. Use a lenient threshold.
    trainable = coverage >= 0.01  # 1% threshold (configurable)
    
    # --- 15. Feature indices for scaling ---
    # Compute indices dynamically to avoid mismatch when feature_order changes
    onehot_idx = list(range(3, 13))  # LULC one-hot features
    cont_idx = [i for i, name in enumerate(feature_order) if i not in onehot_idx]
    noscale_idx = []  # Features that don't need scaling
    
    # --- 16. Season classification ---
    if month in [12, 1, 2]:
        season = "winter"
    elif month in [3, 4, 5]:
        season = "spring"
    elif month in [6, 7, 8]:
        season = "summer"
    else:
        season = "autumn"
    
    # --- 17. SO2-specific metadata for sampling weights ---
    # lag1_fill_ratio computed BEFORE imputation above
    
    return X, y, mask, feature_order, cont_idx, onehot_idx, noscale_idx, coverage, trainable, season, doy, weekday, year_len, lag1_fill_ratio, neighbor_fill_ratio

def test_single_day_so2():
    """Test single day SO2 processing with assertions"""
    
    print("🧪 Testing single day SO2 feature stack creation...")
    
    # Test date
    test_date = "2019-09-01"
    test_year = 2019
    test_day_of_year = 244  # September 1st is day 244 of 2019
    
    # Load weekday weights
    weights_file = PATHS['WEIGHTS_SO2']
    if os.path.exists(weights_file):
        df_weights = pd.read_csv(weights_file)
        print(f"✅ Loaded SO2 weekday weights for {len(df_weights)} days")
    else:
        print("⚠️ SO2 weekday weights file not found, using default weights")
        df_weights = pd.DataFrame({'weekday': range(7), 'weight': [1.0]*7})
    
    # Create feature stack
    X, y, mask, feature_order, cont_idx, onehot_idx, noscale_idx, coverage, trainable, season, doy, weekday, year_len, lag1_fill_ratio, neighbor_fill_ratio = create_single_day_feature_stack_so2(
        test_date, test_year, test_day_of_year, df_weights
    )
    
    # Assertions for SO2 (with wind features total = 27)
    assert X.shape[1:] == (300, 621), f"spatial shape must be (300,621), got {X.shape}"
    assert X.dtype == np.float32, "X must be float32"
    
    # Continuous variables should not be all-NaN on valid pixels
    valid = (mask == 1)
    for i in cont_idx:
        if np.isnan(X[i][valid]).all():
            print(f"⚠️ Warning: feature {feature_order[i]} has all-NaN on valid pixels")
    
    # --- Print results ---
    print(f"\n✅ SO2 test completed successfully!")
    print(f"   Date: {test_date}")
    print(f"   X shape: {X.shape}")
    print(f"   y shape: {y.shape}")
    print(f"   mask shape: {mask.shape}")
    print(f"   Coverage: {coverage:.3f}")
    print(f"   Trainable: {trainable}")
    print(f"   Season: {season}")
    # Sanity checks
    assert X.shape[0] == len(feature_order) == 30, (X.shape[0], len(feature_order))
    # Convert any Inf to NaN; keep NaN for masking downstream
    X[np.isinf(X)] = np.nan
    print(f"   Features: {len(feature_order)}")
    print(f"   DOY: {doy}, Weekday: {weekday}, Year length: {year_len}")
    print(f"   Fill ratios - Lag1: {lag1_fill_ratio:.3f}, Neighbor: {neighbor_fill_ratio:.3f}")
    print(f"   trainable: {trainable}")
    
    # --- Save test result with metadata ---
    output_dir = "/content/drive/MyDrive/Variables/so2_feature_stacks_test"
    os.makedirs(output_dir, exist_ok=True)
    
    output_file = f"{output_dir}/features_so2_test_{test_date.replace('-', '')}.npz"
    
    # Save npz with metadata:
    with open(output_file, "wb") as fh:
        np.savez_compressed(
            fh,
            X=X, y=y, mask=mask,
            feature_names=feature_order,
            cont_idx=cont_idx, onehot_idx=onehot_idx, noscale_idx=noscale_idx,
            coverage=coverage, trainable=trainable,
            pollutant="SO2", season=season, date=test_date,
            doy=doy, weekday=weekday, year_len=year_len,
            grid_height=300, grid_width=621,
            lag1_fill_ratio=lag1_fill_ratio, neighbor_fill_ratio=neighbor_fill_ratio,
            file_version="1.0"
        )
    
    print(f"💾 SO2 test result saved: {output_file}")
    
    return X, y, mask, feature_order, cont_idx, onehot_idx, noscale_idx, coverage, trainable, season, doy, weekday, year_len, lag1_fill_ratio, neighbor_fill_ratio

# Run the test
if __name__ == "__main__":
    test_single_day_so2()

# ===== Convenience helpers for saving in NO2-aligned structure =====

def save_so2_stack(date_str: str, out_base: str = "/content/drive/MyDrive/Feature_Stacks") -> str:
    """Build and save a single-day SO2 feature stack to
    {out_base}/SO2_{year}/SO2_stack_YYYYMMDD.npz (NO2-aligned structure).

    Returns path to saved file (or raises on error).
    """
    dt = datetime.strptime(date_str, "%Y-%m-%d") if "-" in date_str else datetime.strptime(date_str, "%Y%m%d")
    year = dt.year
    doy = dt.timetuple().tm_yday

    # Load weekday weights
    if os.path.exists(PATHS['WEIGHTS_SO2']):
        dfw = pd.read_csv(PATHS['WEIGHTS_SO2'])
    else:
        dfw = pd.DataFrame({'weekday': range(7), 'weight': [1.0]*7})

    # Build
    X, y, mask, feature_order, cont_idx, onehot_idx, noscale_idx, coverage, trainable, \
        season, doy_val, weekday, year_len, lag1_fill_ratio, neighbor_fill_ratio = \
        create_single_day_feature_stack_so2(date_str, year, doy, dfw)

    # Prepare output
    out_dir = os.path.join(out_base, f"SO2_{year}")
    os.makedirs(out_dir, exist_ok=True)
    out_file = os.path.join(out_dir, f"SO2_stack_{dt.strftime('%Y%m%d')}.npz")

    # Save (file handle -> no temp file)
    with open(out_file, "wb") as fh:
        np.savez_compressed(
            fh,
            X=X, y=y, mask=mask,
            feature_names=feature_order,
            cont_idx=cont_idx, onehot_idx=onehot_idx, noscale_idx=noscale_idx,
            coverage=coverage, trainable=trainable,
            pollutant="SO2", season=season, date=dt.strftime('%Y-%m-%d'),
            doy=doy_val, weekday=weekday, year_len=year_len,
            grid_height=300, grid_width=621,
            lag1_fill_ratio=lag1_fill_ratio, neighbor_fill_ratio=neighbor_fill_ratio,
            file_version="1.0"
        )

    return out_file


def generate_so2_year(year: int, out_base: str = "/content/drive/MyDrive/Feature_Stacks", resume: bool = True) -> None:
    """Generate and save a full-year SO2 stacks to NO2-aligned structure.

    - out_base/SO2_{year}/SO2_stack_YYYYMMDD.npz
    - resume=True: 已存在的文件将被跳过
    """
    print(f"🚀 Generating SO2 stacks for {year} → {out_base}/SO2_{year}")

    # Days in year
    days_in_year = 366 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 365

    out_dir = os.path.join(out_base, f"SO2_{year}")
    os.makedirs(out_dir, exist_ok=True)

    done = 0
    for day in range(1, days_in_year + 1):
        dt = datetime(year, 1, 1) + timedelta(days=day - 1)
        out_file = os.path.join(out_dir, f"SO2_stack_{dt.strftime('%Y%m%d')}.npz")
        if resume and os.path.exists(out_file):
            done += 1
            if day % 50 == 0:
                print(f"  ✅ {day}/{days_in_year} (skipping existing)")
            continue
        try:
            save_so2_stack(dt.strftime('%Y-%m-%d'), out_base=out_base)
            done += 1
            if day % 50 == 0:
                print(f"  ✅ {day}/{days_in_year}")
        except Exception as e:
            print(f"  ❌ {dt.strftime('%Y-%m-%d')}: {e}")

    print(f"🎉 Finished {year}: {done}/{days_in_year} files")
