# ===== NO2 3D CNN 最终修复版训练代码 =====
"""
NO2 3D CNN Final Fixed Training Script

中文/English 双语说明 / Bilingual guide

本脚本包含完整的 NO2 三维卷积网络训练流水线：
- 数据集定义 `NO2_3DCNN_Dataset`
- 模型结构 `NO2_3DCNN_Model`
- 损失函数 `NO2_3DCNN_Loss`
- 训练器 `NO2_3DCNN_Trainer`
- 早停策略 `EarlyStopping`
- 主流程 `main()`

This script provides an end-to-end pipeline for training a 3D CNN for NO2:
- Dataset definition `NO2_3DCNN_Dataset`
- Model architecture `NO2_3DCNN_Model`
- Loss function `NO2_3DCNN_Loss`
- Trainer `NO2_3DCNN_Trainer`
- Early stopping `EarlyStopping`
- Entry point `main()`

使用要点 / Key usage notes:
1) 配置项集中在 `NO2_3DCNN_CONFIG`，请根据环境与数据路径修改。
2) 数据集按天构成时间窗口，提取空间 patch，并进行特征/目标标准化。
3) 训练时仅监督最后一帧（常用于缺测值插补/预报的 next-step 设定）。
4) 训练与验证均打印详细诊断信息，便于快速排查数据有效性与数值稳定性。

1) All parameters are set in `NO2_3DCNN_CONFIG` — update paths as needed.
2) Dataset builds temporal windows over daily stacks, extracts spatial patches, and standardizes features/targets.
3) Loss supervises only the last frame (typical for gap-filling/next-step targets).
4) Verbose diagnostics help validate data integrity and numerical stability.
"""
# [Step 0 / 步骤0] Imports and global setup 导入与全局设置
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
import os
import sys
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# [Step 0.1 / 步骤0.1] Select device 选择计算设备
# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🚀 使用设备: {device}")

# ===== 最终修复版配置参数 =====
# [Step 1 / 步骤1] Configure training pipeline 配置训练流水线
NO2_3DCNN_CONFIG = {
    # 数据根目录（需包含 NO2_YYYY/NO2_stack_*.npz）
    # Root dir containing per-year folders with per-day stacks
    'data_path': '/content/drive/MyDrive/Feature_Stacks',
    # 特征标准化统计文件（包含 channel_list/mean/std）
    # Scaler npz with channel_list/mean/std dicts
    'scaler_path': '/content/drive/MyDrive/3DCNN_Pipeline/artifacts/scalers/NO2/meanstd_global_2019_2021.npz',
    # 时间窗口长度（天数）/ Temporal window length (days)
    'time_window': 7,
    # 批大小 / Batch size
    'batch_size': 8,
    # 训练轮数（示例设置，实际可更大）/ Number of epochs (example)
    'num_epochs': 3,
    # 学习率 / Learning rate
    'learning_rate': 1e-4,
    # 早停耐心值 / Early stopping patience
    'patience': 5,
    # 训练/验证/测试年份划分 / Train/Val/Test years
    'train_years': [2019, 2020, 2021],
    'val_year': 2022,
    'test_year': 2023,
    # 梯度裁剪阈值 / Max gradient norm (clip)
    'max_grad_norm': 1.0,
    # 自动混合精度（仅 CUDA 有效）/ AMP (CUDA only)
    'use_amp': True,
    # Patch设置
    # 空间 patch 尺寸 / Spatial patch size
    'patch_size': 64,
    # 时间随机缺口比例（训练增强，不含最后一帧）/ Temporal gap ratio (excluding last frame)
    'patch_gap_ratio': 0.2,
    # 空间随机缺口比例（训练增强）/ Spatial gap ratio for masking
    'spatial_gap_ratio': 0.15,
    # 有效像素最低比例阈值（用于样本与损失计算过滤）/ Minimum valid pixel ratio
    'min_valid_ratio': 0.1,
    # NO2目标值标准化参数
    # target normalization parameters (global mean/std)
    'mu_y': 1.54890004506932e-05,
    'std_y': 3.894585466518877e-05,
}

print("📊 NO2 3D CNN 最终修复版配置:")
for key, value in NO2_3DCNN_CONFIG.items():
    print(f"  {key}: {value}")

# ===== 最终修复版NO2数据集类 =====
# [Step 2 / 步骤2] Define dataset 定义数据集
class NO2_3DCNN_Dataset(Dataset):
    """
    NO2 3D 时空数据集（按天堆叠为时间窗口 + 空间 patch）

    功能概述 / Overview:
    - 读取每日栅格 .npz，包含特征与 NO2 目标与掩码
    - 构建长度为 T 的时间窗口（滑动窗口），并抽取 HxW 的空间 patch
    - 使用提供的 scaler 对各特征通道进行标准化（均值/标准差）
    - 训练时注入时间/空间随机缺口以增强鲁棒性（不影响最后一帧）

    This dataset builds temporal windows over daily raster stacks and extracts
    spatial patches. Feature channels are standardized via a provided scaler.
    During training, random temporal/spatial gaps are injected for robustness.

    参数 / Args:
    - data_path: 特征栈根路径 / root path to feature stacks
    - scaler_path: 标准化器路径（.npz）/ path to scaler npz
    - time_window: 时间窗口长度 T / temporal window length T
    - train_years / val_year / test_year: 年份划分 / year splits
    - is_train: 训练/验证模式开关 / training mode flag
    - patch_size: 空间 patch 边长 / spatial patch size
    - patch_gap_ratio: 时间缺口比例 / temporal gap ratio
    - spatial_gap_ratio: 空间缺口比例 / spatial gap ratio
    - min_valid_ratio: 最小有效像素比例（过滤批次/损失）/ min valid pixel ratio
    """
    def __init__(self, data_path, scaler_path, time_window=7,
                 train_years=[2019, 2020, 2021], val_year=2022, test_year=2023,
                 is_train=True, patch_size=64, patch_gap_ratio=0.2,
                 spatial_gap_ratio=0.15, min_valid_ratio=0.1):
        self.data_path = data_path
        self.time_window = time_window
        self.is_train = is_train
        self.H, self.W = 300, 621
        self.patch_size = patch_size
        self.patch_gap_ratio = patch_gap_ratio
        self.spatial_gap_ratio = spatial_gap_ratio
        self.min_valid_ratio = min_valid_ratio

        # 锁定特征名和通道数机制
        self.active_feature_names = None
        self.active_num_channels = None

        # 标准化缓存机制
        self._ms_cached_names = None
        self._ms_means = None
        self._ms_stds = None

        # 日志控制
        self._print_load_count = 0
        self._print_invalid_count = 0

        # [Step 2.1 / 步骤2.1] Load scaler 加载标准化器
        self._load_scaler(scaler_path)

        # [Step 2.2 / 步骤2.2] Compute channel count 计算通道数
        self.num_channels = len(self.feature_order)

        # [Step 2.3 / 步骤2.3] Build file lists 构建文件列表
        self._get_file_lists(train_years, val_year, test_year)

        # [Step 2.4 / 步骤2.4] Build valid temporal windows 构建有效时间窗口
        self._build_valid_windows()

        print(f"📊 NO2 3D数据集初始化完成:")
        print(f"  训练文件: {len(self.train_files)}")
        print(f"  验证文件: {len(self.val_files)}")
        print(f"  测试文件: {len(self.test_files)}")
        print(f"  时间窗口: {time_window}天")
        print(f"  特征数: {len(self.feature_order)}")
        print(f"  有效窗口数: {len(self.valid_windows)}")

    def _load_scaler(self, scaler_path):
        # [Step 2.a / 步骤2.a] Scaler loader 标准化器加载器
        """
        加载 NO2 特征标准化器（含通道顺序、均值与标准差字典）

        Load the NO2 scaler which includes:
        - feature_order: ordered list of channel names
        - mean_dict/std_dict: per-feature mean and std for standardization

        当标准化器不可用时，回退到一组默认特征与 (0,1) 标准化。
        If loading fails, fall back to default feature list with zero-mean unit-std.
        """
        try:
            with np.load(scaler_path, allow_pickle=True) as data:
                self.feature_order = data['channel_list'].tolist()
                self.mean_dict = data['mean'].item()
                self.std_dict = data['std'].item()
                print(f"✅ NO2标准化器加载成功: {len(self.feature_order)} 个特征")
                print(f"📊 特征顺序: {self.feature_order[:5]}...")

                # 验证scaler数据
                print(f"📊 NO2标准化器验证:")
                print(f"  mean字典键数: {len(self.mean_dict)}")
                print(f"  std字典键数: {len(self.std_dict)}")
                print(f"  前3个特征的统计信息:")
                for i, feat in enumerate(self.feature_order[:3]):
                    if feat in self.mean_dict and feat in self.std_dict:
                        mean_val = self.mean_dict[feat]
                        std_val = self.std_dict[feat]
                        print(f"    {feat}: mean={mean_val:.6f}, std={std_val:.6f}")
                    else:
                        print(f"    {feat}: 缺少统计信息")
        except Exception as e:
            print(f"⚠️ NO2标准化器加载失败: {e}")
            # 使用NO2默认特征
            self.feature_order = [
                'dem', 'slope', 'pop', 'lulc_class_0', 'lulc_class_1', 'lulc_class_2',
                'lulc_class_3', 'lulc_class_4', 'lulc_class_5', 'lulc_class_6',
                'lulc_class_7', 'lulc_class_8', 'lulc_class_9', 'sin_doy', 'cos_doy',
                'weekday_weight', 'u10', 'v10', 'blh', 'tp', 't2m', 'sp', 'str',
                'ssr_clr', 'ws', 'wd_sin', 'wd_cos', 'no2_lag_1day', 'no2_neighbor'
            ]
            self.mean_dict = {feat: 0.0 for feat in self.feature_order}
            self.std_dict = {feat: 1.0 for feat in self.feature_order}

    def _get_file_lists(self, train_years, val_year, test_year):
        # [Step 3 / 步骤3] Enumerate daily stacks 枚举各年日栈文件
        """
        获取各年份的栈文件路径列表（按文件名排序）

        Build lists of daily stack file paths for train/val/test years.
        文件命名期望形如 NO2_stack_*.npz，便于按字典序排序即为时间序。
        File names are expected like NO2_stack_*.npz so lexicographic order matches time.
        """
        self.train_files = []
        self.val_files = []
        self.test_files = []

        for year in train_years:
            year_dir = os.path.join(self.data_path, f'NO2_{year}')
            if os.path.exists(year_dir):
                files = sorted([f for f in os.listdir(year_dir) if f.startswith('NO2_stack_') and f.endswith('.npz')])
                self.train_files.extend([os.path.join(year_dir, f) for f in files])

        for year in [val_year, test_year]:
            year_dir = os.path.join(self.data_path, f'NO2_{year}')
            if os.path.exists(year_dir):
                files = sorted([f for f in os.listdir(year_dir) if f.startswith('NO2_stack_') and f.endswith('.npz')])
                if year == val_year:
                    self.val_files.extend([os.path.join(year_dir, f) for f in files])
                else:
                    self.test_files.extend([os.path.join(year_dir, f) for f in files])

    def _build_valid_windows(self):
        # [Step 4 / 步骤4] Build temporal windows 构建时间滑动窗口
        """
        构建滑动时间窗口起点索引列表 / Build sliding window start indices.

        - 若文件数量 < T 则抛出异常
        - 简化实现：不跨文件缺口进行过滤，窗口按顺序滑动
        """
        self.valid_windows = []

        if self.is_train:
            file_list = self.train_files
        else:
            file_list = self.val_files if hasattr(self, 'val_files') and len(self.val_files) > 0 else self.test_files

        # 样本数量保护
        if len(file_list) < self.time_window:
            raise RuntimeError(f"可用文件不足:仅{len(file_list)} 个文件,但time_window={self.time_window}")

        # 简化：直接按索引构建窗口
        for i in range(len(file_list) - self.time_window + 1):
            self.valid_windows.append(i)

        print(f"📅 构建了 {len(self.valid_windows)} 个时间窗口")

    def _load_single_file(self, file_path):
        # [Step 5 / 步骤5] Load one day and align features 加载一天数据并对齐特征
        """
        加载单日 NO2 栈文件，返回 (X, y, mask, feature_names)

        Load one daily NO2 stack and return:
        - X: (C,H,W) features in scaler order, missing filled with NaN
        - y: (H,W) target grid (cleaned from sentinel values)
        - mask: (H,W) boolean mask of valid target pixels
        - feature_names: the scaler-ordered feature name list aligned to X

        关键步骤 / Steps:
        1) 基本键检查与目标/掩码读取
        2) 目标值异常值清理（哨兵值、极值）
        3) 对齐空间尺寸到 (H,W)
        4) 依据 scaler 的通道顺序装配特征，必要时做名称映射
        5) 基本有效性检查（有效像素计数）
        """
        try:
            with np.load(file_path, allow_pickle=True) as data:
                # 检查必要数据
                if 'no2_target' not in data or 'no2_mask' not in data:
                    print(f"⚠️ 文件缺少必要数据: {os.path.basename(file_path)}")
                    return None

                y = data['no2_target']  # NO2目标值
                mask = data['no2_mask']  # NO2掩码

                # 数据清理
                if isinstance(y, np.ndarray) and y.dtype.kind in 'fi':
                    for s in (-9999, -32768):
                        y = np.where(y == s, np.nan, y)
                    y = np.where(np.abs(y) > 1e6, np.nan, y)

                # 检查空间尺寸
                if y.shape != (self.H, self.W):
                    print(f"⚠️ 空间尺寸不匹配: {y.shape} vs ({self.H}, {self.W})")
                    y_resized = np.full((self.H, self.W), np.nan, dtype=y.dtype)
                    mask_resized = np.zeros((self.H, self.W), dtype=bool)

                    min_h = min(y.shape[0], self.H)
                    min_w = min(y.shape[1], self.W)
                    y_resized[:min_h, :min_w] = y[:min_h, :min_w]
                    mask_resized[:min_h, :min_w] = mask[:min_h, :min_w]

                    y = y_resized
                    mask = mask_resized

                # 构建特征矩阵 - 最终修复版，处理特征映射
                X_features = []
                feature_names = []

                # 特征映射字典
                feature_mapping = {
                    'pop': 'population',
                    'ssr_clr': 'ssr',
                    'no2_lag_1day': 'lag1',
                    'no2_neighbor': 'neighbor',
                    'lulc_class_0': 'lulc_01',
                    'lulc_class_1': 'lulc_02',
                    'lulc_class_2': 'lulc_03',
                    'lulc_class_3': 'lulc_04',
                    'lulc_class_4': 'lulc_05',
                    'lulc_class_5': 'lulc_06',
                    'lulc_class_6': 'lulc_07',
                    'lulc_class_7': 'lulc_08',
                    'lulc_class_8': 'lulc_09',
                    'lulc_class_9': 'lulc_10'
                }

                # 在_Load_single_file 读取 data 后
                rev_map = {
                    'population': 'pop', 'ssr': 'ssr_clr', 'lag1': 'no2_lag_1day', 'neighbor': 'no2_neighbor',
                    'lulc_01': 'lulc_class_0', 'lulc_02': 'lulc_class_1', 'lulc_03': 'lulc_class_2',
                    'lulc_04': 'lulc_class_3', 'lulc_05': 'lulc_class_4', 'lulc_06': 'lulc_class_5',
                    'lulc_07': 'lulc_class_6', 'lulc_08': 'lulc_class_7', 'lulc_09': 'lulc_class_8',
                    'lulc_10': 'lulc_class_9'
                }
                data_keys = set(k for k in data.keys() if k not in ['no2_target', 'no2_mask', 'year', 'day'])

                # [Step 5.1 / 步骤5.1] Map and align feature channels 通道名映射并按 scaler 顺序对齐
                # 按 scaler 通道顺序加载特征；若数据键不同则通过映射表反查
                # Load features in scaler order; resolve naming via reverse map if needed
                for scaler_feat in self.feature_order:
                    candidate = scaler_feat if scaler_feat in data_keys else rev_map.get(scaler_feat, None)
                    if candidate in data_keys:
                        feat_data = data[candidate]

                        # 调整特征数据尺寸
                        if feat_data.shape != (self.H, self.W):
                            feat_resized = np.full((self.H, self.W), np.nan, dtype=feat_data.dtype)
                            min_h = min(feat_data.shape[0], self.H)
                            min_w = min(feat_data.shape[1], self.W)
                            feat_resized[:min_h, :min_w] = feat_data[:min_h, :min_w]
                            feat_data = feat_resized

                        X_features.append(feat_data)
                        feature_names.append(scaler_feat)
                    else:
                        X_features.append(np.full((self.H, self.W), np.nan, dtype=np.float32))
                        feature_names.append(scaler_feat)

                if not X_features:
                    return None

                # [Step 5.2 / 步骤5.2] Stack features to channel-first 堆叠为通道优先张量
                X = np.stack(X_features, axis=0)  # (C, H, W) 通道优先 / channel-first

                # 检查是否有有效数据
                valid_pixels = np.sum(mask)
                if valid_pixels == 0:
                    if self._print_invalid_count < 3:
                        print(f"⚠️ NO2文件没有有效数据: {os.path.basename(file_path)}")
                        self._print_invalid_count += 1
                    elif self._print_invalid_count == 3:
                        print(f"⚠️ NO2文件没有有效数据: ... (后续类似警告将不再显示)")
                        self._print_invalid_count += 1
                    return None

                if self._print_load_count < 5:
                    print(f"✅ 成功加载NO2文件: {os.path.basename(file_path)}, 有效像素: {valid_pixels}, 特征形状: {X.shape}")
                    self._print_load_count += 1
                return X, y, mask, feature_names

        except Exception as e:
            print(f"⚠️ NO2文件加载失败 {os.path.basename(file_path)}: {e}")
            return None

    def _vectorized_scaling(self, X_tensor, feature_names):
        # [Step 6 / 步骤6] Standardize features 标准化特征
        """
        向量化标准化（兼容 4D/5D）：
        - 输入可能为 (T,C,H,W) 或 (B,T,C,H,W)
        - 使用缓存的均值/标准差 (1,C,1,1) 广播实现

        Vectorized feature standardization supporting 4D/5D tensors.
        """
        # 使用scaler进行标准化
        if self._ms_cached_names is None or self._ms_means is None or self._ms_stds is None:
            self._ensure_ms(feature_names)

        # 应用标准化
        X_tensor = torch.nan_to_num(X_tensor, 0.0, 0.0, 0.0)

        # 使用缓存的均值和标准差，兼容4D/5D张量
        if self._ms_means is not None and self._ms_stds is not None:
            if X_tensor.dim() == 4:
                # 4D张量: (T, C, H, W)
                X_tensor = (X_tensor - self._ms_means) / self._ms_stds
            elif X_tensor.dim() == 5:
                # 5D张量: (B, T, C, H, W) - 添加batch维度
                X_tensor = (X_tensor - self._ms_means.unsqueeze(0)) / self._ms_stds.unsqueeze(0)

        return X_tensor

    def _ensure_ms(self, feature_names):
        # [Step 6.1 / 步骤6.1] Prepare mean/std buffers 准备均值/标准差缓冲
        """
        准备并缓存均值/标准差张量，形状为 (1,C,1,1) 便于广播。

        Build and cache per-channel mean/std tensors with shape (1,C,1,1)
        for broadcast in both 4D and 5D inputs.
        """
        if feature_names is None:
            feature_names = self.feature_order

        # 构建均值和标准差张量
        means = []
        stds = []

        for feat in feature_names:
            if feat in self.mean_dict and feat in self.std_dict:
                means.append(self.mean_dict[feat])
                stds.append(self.std_dict[feat])
            else:
                means.append(0.0)
                stds.append(1.0)

        # 正确广播形状: (1, C, 1, 1) 用于 (T, C, H, W)
        self._ms_means = torch.tensor(means, dtype=torch.float32).view(1, -1, 1, 1)
        self._ms_stds = torch.tensor(stds, dtype=torch.float32).view(1, -1, 1, 1)
        self._ms_cached_names = feature_names

        print(f"📊 缓存了 {len(feature_names)} 个特征的标准化参数")

    def __len__(self):
        return len(self.valid_windows)

    def __getitem__(self, idx):
        # [Step 7 / 步骤7] Assemble one training sample 组装一个训练样本
        window_start = self.valid_windows[idx]

        if self.is_train:
            file_list = self.train_files
        else:
            file_list = self.val_files if hasattr(self, 'val_files') and len(self.val_files) > 0 else self.test_files

        # [Step 7.1 / 步骤7.1] Load temporal window 加载时间窗口数据
        X_window = []
        y_window = []
        mask_window = []

        for i in range(self.time_window):
            file_path = file_list[window_start + i]
            data = self._load_single_file(file_path)

            if data is None:
                # 用NaN填充缺失数据
                X_nan = np.full((self.num_channels, self.H, self.W), np.nan, dtype=np.float32)  # 使用动态通道数
                y_nan = np.full((self.H, self.W), np.nan, dtype=np.float32)
                mask_nan = np.zeros((self.H, self.W), dtype=bool)
                X_window.append(X_nan)
                y_window.append(y_nan)
                mask_window.append(mask_nan)
            else:
                X, y, mask, feature_names = data
                X_window.append(X)
                y_window.append(y)
                mask_window.append(mask)

        # [Step 7.2 / 步骤7.2] Stack time dimension 堆叠时间维度
        X_window = np.stack(X_window, axis=0)  # (T, C, H, W)
        y_window = np.stack(y_window, axis=0)   # (T, H, W)
        mask_window = np.stack(mask_window, axis=0)  # (T, H, W)

        # [Step 7.3 / 步骤7.3] Apply synthetic gaps (train only) 训练专用缺口增强
        X_window, y_window, mask_window = self._apply_gaps(X_window, y_window, mask_window)

        # [Step 7.4 / 步骤7.4] Extract spatial patch 提取空间 patch（随机或中心）
        X_patch, y_patch, mask_patch = self._extract_patch(X_window, y_window, mask_window)

        # [Step 7.5 / 步骤7.5] Convert to tensors 转换为 Tensor
        X_tensor = torch.from_numpy(X_patch).float()
        y_tensor = torch.from_numpy(y_patch).float()
        mask_tensor = torch.from_numpy(mask_patch).bool()

        # [Step 7.6 / 步骤7.6] Vectorized standardization 向量化标准化
        X_tensor = self._vectorized_scaling(X_tensor, None)

        # [Step 7.7 / 步骤7.7] Normalize target 标准化目标值
        # 目标值标准化：先将无效像素置 0（便于 loss 过滤），再做 z-score
        # Target normalization: set invalid to 0, then z-score using global stats
        y_tensor[~mask_tensor] = 0.0  # 将无效值设为0而不是-999.0
        mu_y = NO2_3DCNN_CONFIG['mu_y']
        std_y = NO2_3DCNN_CONFIG['std_y']
        y_tensor = (y_tensor - mu_y) / std_y

        # [Step 7.8 / 步骤7.8] Build labels for loss 构建损失用标签
        # 构建损失用标签（用 -999.0 标记无效，以便损失函数过滤）
        y_for_loss = y_tensor.clone()
        y_for_loss[~mask_tensor] = -999.0

        return X_tensor, y_for_loss, mask_tensor

    def _extract_patch(self, X, y, mask):
        # [Step 8 / 步骤8] Patch sampling and validation patch 抽样与有效性校验
        """
        提取空间 patch：
        - 训练：随机位置（最多重试 N 次以满足有效像素比例）
        - 验证/测试：居中裁剪

        Extract spatial patch. Train: random with retries to meet min valid ratio;
        Eval/Test: center crop.
        """
        retries, max_retries = 0, 20

        while True:
            if not self.is_train:
                center_h = self.H // 2
                center_w = self.W // 2
                start_h = max(0, center_h - self.patch_size // 2)
                start_w = max(0, center_w - self.patch_size // 2)
            else:
                max_h = max(1, self.H - self.patch_size)
                max_w = max(1, self.W - self.patch_size)
                start_h = np.random.randint(0, max_h + 1)
                start_w = np.random.randint(0, max_w + 1)

            end_h = min(self.H, start_h + self.patch_size)
            end_w = min(self.W, start_w + self.patch_size)

            X_patch = X[:, :, start_h:end_h, start_w:end_w]
            y_patch = y[:, start_h:end_h, start_w:end_w]
            mask_patch = mask[:, start_h:end_h, start_w:end_w]

            valid_ratio = np.sum(mask_patch[-1]) / mask_patch[-1].size
            if valid_ratio >= self.min_valid_ratio or not self.is_train:
                return X_patch, y_patch, mask_patch

            if not self.is_train:
                return X_patch, y_patch, mask_patch

            retries += 1
            if retries >= max_retries:
                return X_patch, y_patch, mask_patch

    def _apply_gaps(self, X, y, mask):
        # [Step 9 / 步骤9] Data augmentation by gaps 缺口增强
        """
        应用随机时间/空间缺口（仅训练）：
        - 时间：随机选择部分时间步（不含最后一帧）置为 NaN/False
        - 空间：随机位置像素在随机时间步置 NaN/False（同样不伤最后一帧）

        Apply random temporal/spatial gaps for augmentation during training only.
        """
        if not self.is_train:
            return X, y, mask

        X_gapped = X.copy()
        y_gapped = y.copy()
        mask_gapped = mask.copy()

        # 时间缺口 - 不包含最后一帧
        time_steps = X.shape[0]
        last = time_steps - 1
        n_time_gaps = int(time_steps * self.patch_gap_ratio)
        if n_time_gaps > 0 and last > 0:
            pool = np.arange(0, last)  # 不包含最后一帧
            gap_indices = np.random.choice(pool, min(n_time_gaps, len(pool)), replace=False)
            X_gapped[gap_indices] = np.nan
            y_gapped[gap_indices] = np.nan
            mask_gapped[gap_indices] = False

        # 空间缺口 (不伤最后一帧) — 向量化版本
        H, W = X.shape[2], X.shape[3]
        n_spatial_gaps = int(H * W * self.spatial_gap_ratio)
        if n_spatial_gaps > 0:
            last = X.shape[0] - 1
            if last > 0:
                t_idx = np.random.randint(0, last, size=n_spatial_gaps)  # 0..last-1
                h_idx = np.random.randint(0, H, size=n_spatial_gaps)
                w_idx = np.random.randint(0, W, size=n_spatial_gaps)
                X_gapped[t_idx, :, h_idx, w_idx] = np.nan
                y_gapped[t_idx, h_idx, w_idx] = np.nan
                mask_gapped[t_idx, h_idx, w_idx] = False

        return X_gapped, y_gapped, mask_gapped

# ===== 最终修复版NO2 3D CNN模型 =====
# [Step 10 / 步骤10] Define 3D CNN model 定义 3D CNN 模型
class NO2_3DCNN_Model(nn.Module):
    def __init__(self, input_channels=29, out_in_01=False):
        super().__init__()
        self.out_in_01 = out_in_01
        ch = 32
        # [Step 10.1 / 步骤10.1] Backbone 主干（3D 卷积 + GroupNorm + ReLU）
        # Backbone: 3x [Conv3D -> GroupNorm -> ReLU]
        self.body = nn.Sequential(
            nn.Conv3d(input_channels, ch, 3, padding=1),
            nn.GroupNorm(num_groups=8, num_channels=ch),
            nn.ReLU(inplace=True),

            nn.Conv3d(ch, ch*2, 3, padding=1),
            nn.GroupNorm(num_groups=8, num_channels=ch*2),
            nn.ReLU(inplace=True),

            nn.Conv3d(ch*2, ch*4, 3, padding=1),
            nn.GroupNorm(num_groups=8, num_channels=ch*4),
            nn.ReLU(inplace=True),
        )

        # [Step 11 / 步骤11] Prediction head 预测头（1x1x1 卷积 -> 1 通道）
        # Head: 1x1x1 conv to single-channel output
        self.head = nn.Conv3d(ch*4, 1, 1)

    def forward(self, x):
        """
        # [Step 12 / 步骤12] Forward pass 前向传播
        前向传播 / Forward pass
        - 输入: (B, T, C, H, W)
        - 内部: 重新排列为 (B, C, T, H, W) 以适配 Conv3D
        - 输出: (B, 1, T, H, W)，若 out_in_01 则经 sigmoid 压至 [0,1]
        """
        x = x.permute(0, 2, 1, 3, 4)  # (B, C, T, H, W)
        x = self.body(x)
        x = self.head(x)

        # 不强制使用sigmoid，让模型学习原始范围
        if self.out_in_01:
            x = torch.sigmoid(x)

        return x

# ===== 最终修复版NO2损失函数 =====
# [Step 13 / 步骤13] Define loss function 定义损失函数
class NO2_3DCNN_Loss(nn.Module):
    def __init__(self, supervise_last_frame_only=True, min_valid_ratio=0.01):
        super().__init__()
        self.supervise_last_frame_only = supervise_last_frame_only
        self.min_valid_ratio = min_valid_ratio
        self.zero_loss_count = 0
        self.total_batches = 0

    def forward(self, pred, target, mask):
        """
        # [Step 13.1 / 步骤13.1] Compute masked MSE 计算带掩码的 MSE
        计算 MSE 损失（带有效性过滤）：
        - 默认仅监督最后一帧：与 many-to-one/next-step 设定一致
        - 使用 mask 与 -999.0 标记过滤无效像素
        - 若有效比例过低，返回极小非零损失以避免 NaN/Inf

        Compute masked MSE. By default supervise only the last frame.
        Invalid pixels are filtered via mask and sentinel -999.0.
        If valid ratio is too low, return a tiny non-zero loss.
        """
        self.total_batches += 1
        pred = pred.squeeze(1)  # (B, T, H, W)

        if self.supervise_last_frame_only:
            pred_last = pred[:, -1]  # (B, H, W)
            target_last = target[:, -1]  # (B, H, W)
            mask_last = mask[:, -1]  # (B, H, W)

            valid = torch.isfinite(target_last) & (target_last != -999.0) & mask_last

            total_pixels = target_last.numel()
            valid_pixels = torch.sum(valid).item()
            valid_ratio = valid_pixels / total_pixels if total_pixels > 0 else 0

            if valid_ratio < self.min_valid_ratio:
                self.zero_loss_count += 1
                if self.zero_loss_count <= 5:
                    print(f"⚠️ 批次有效数据比例过低: {valid_ratio:.4f} < {self.min_valid_ratio}")
                return torch.tensor(1e-6, device=pred.device, requires_grad=True)

            if torch.sum(valid) == 0:
                return torch.tensor(1e-6, device=pred.device, requires_grad=True)
            mse_loss = F.mse_loss(pred_last[valid], target_last[valid])
        else:
            valid = torch.isfinite(target) & (target != -999.0) & mask

            total_pixels = target.numel()
            valid_pixels = torch.sum(valid).item()
            valid_ratio = valid_pixels / total_pixels if total_pixels > 0 else 0

            if valid_ratio < self.min_valid_ratio:
                self.zero_loss_count += 1
                if self.zero_loss_count <= 5:
                    print(f"⚠️ 批次有效数据比例过低: {valid_ratio:.4f} < {self.min_valid_ratio}")
                return torch.tensor(1e-6, device=pred.device, requires_grad=True)

            if torch.sum(valid) == 0:
                return torch.tensor(1e-6, device=pred.device, requires_grad=True)
            mse_loss = F.mse_loss(pred[valid], target[valid])

        return mse_loss

# ===== 最终修复版NO2训练器 =====
# [Step 14 / 步骤14] Define trainer 定义训练器
class NO2_3DCNN_Trainer:
    def __init__(self, model, train_loader, val_loader, device, learning_rate=1e-4, patience=3):
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device

        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate, weight_decay=1e-6)
        self.criterion = NO2_3DCNN_Loss(supervise_last_frame_only=True, min_valid_ratio=NO2_3DCNN_CONFIG['min_valid_ratio'])
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, mode='min', patience=2, factor=0.5)

        self.early_stopping = EarlyStopping(patience=patience)
        self.train_losses = []
        self.val_losses = []

        self.use_amp = NO2_3DCNN_CONFIG.get('use_amp', False) and (self.device.type == 'cuda')
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.use_amp)
        self.best_val = float('inf')
        self.best_state = None

        print(f"✅ NO2训练器初始化完成(AMP={'ON' if self.use_amp else 'OFF'})")

    def train_one_epoch(self):
        """
        # [Step 14.1 / 步骤14.1] Train one epoch 训练一个 epoch
        训练单个 epoch：
        - 过滤最后一帧有效像素比例过低的批次
        - AMP 前向与反向、梯度裁剪、学习率调度
        - 打印首批次诊断与周期性损失

        Train one epoch with AMP + gradient clipping and skip low-quality batches.
        """
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        skipped_batches = 0

        for batch_idx, (X, y, mask) in enumerate(self.train_loader):
            X, y, mask = X.to(self.device), y.to(self.device), mask.to(self.device)

            # 检查批次质量
            mask_last = mask[:, -1]
            target_last = y[:, -1]
            valid = torch.isfinite(target_last) & (target_last != -999.0) & mask_last
            valid_ratio = torch.sum(valid).item() / target_last.numel()

            if batch_idx == 0:
                print(f"🔍 NO2第一个批次诊断:")
                print(f"  X shape: {X.shape}, X range: [{X.min():.6f}, {X.max():.6f}]")
                print(f"  y shape: {y.shape}, y range: [{y.min():.6f}, {y.max():.6f}]")
                print(f"  mask shape: {mask.shape}, mask sum: {mask.sum()}")
                print(f"  y == -999.0: {(y == -999.0).sum()}")
                print(f"  valid positions: {((y != -999.0) & mask).sum()}")
                print(f"  最后一帧有效比例: {valid_ratio:.4f}")

            min_vr = NO2_3DCNN_CONFIG['min_valid_ratio']
            if valid_ratio < min_vr:
                skipped_batches += 1
                if skipped_batches <= 3:
                    print(f"  ⚠️ 跳过NO2批次 {batch_idx}: 有效数据比例过低 ({valid_ratio:.4f} < {min_vr})")
                continue

            self.optimizer.zero_grad()

            with torch.cuda.amp.autocast(enabled=self.use_amp):
                pred = self.model(X)

                if batch_idx == 0:
                    print(f"  pred shape: {pred.shape}, pred range: [{pred.min():.6f}, {pred.max():.6f}]")

                loss = self.criterion(pred, y, mask)

            if torch.isnan(loss) or torch.isinf(loss):
                print(f"⚠️ NO2批次 {batch_idx} 损失无效，跳过")
                continue

            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), NO2_3DCNN_CONFIG.get('max_grad_norm', 1.0))
            self.scaler.step(self.optimizer)
            self.scaler.update()

            total_loss += loss.item()
            num_batches += 1

            if batch_idx % 5 == 0:
                print(f"  批次 {batch_idx}: 损失 = {loss.item():.6f}, 有效比例 = {valid_ratio:.4f}")

            if loss.item() == 0.0:
                print(f"  🚨 NO2批次 {batch_idx} 损失为0，详细诊断:")
                print(f"    有效像素数: {torch.sum(valid).item()}")
                print(f"    总像素数: {target_last.numel()}")
                print(f"    有效比例: {valid_ratio:.6f}")
                print(f"    目标值范围: [{target_last.min():.6f}, {target_last.max():.6f}]")
                print(f"    预测值范围: [{pred[:, -1].min():.6f}, {pred[:, -1].max():.6f}]")

        if skipped_batches > 0:
            print(f"  📊 跳过了 {skipped_batches} 个低质量NO2批次")

        return total_loss / max(num_batches, 1)

    def validate_one_epoch(self):
        """
        # [Step 15 / 步骤15] Validate one epoch 验证一个 epoch
        在验证集上评估平均损失（不更新梯度）。

        Evaluate avg loss on validation set without gradient updates.
        """
        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch_idx, (X, y, mask) in enumerate(self.val_loader):
                X, y, mask = X.to(self.device), y.to(self.device), mask.to(self.device)

                pred = self.model(X)
                loss = self.criterion(pred, y, mask)

                if torch.isnan(loss) or torch.isinf(loss):
                    continue

                total_loss += loss.item()
                num_batches += 1

        return total_loss / max(num_batches, 1)

    def train(self, num_epochs):
        """
        # [Step 16 / 步骤16] Full training loop 完整训练循环
        完整训练循环：
        - 对每个 epoch 执行训练与验证
        - 维护并保存最佳验证模型（含配置与损失追踪）
        - 早停与最终模型保存

        Full training loop with best checkpointing and early stopping.
        """
        print(f"🚀 开始NO2训练 {num_epochs} 个epoch...")

        for epoch in range(num_epochs):
            print(f"\n📊 NO2 Epoch {epoch+1}/{num_epochs}")

            train_loss = self.train_one_epoch()
            self.train_losses.append(train_loss)

            val_loss = self.validate_one_epoch()
            self.val_losses.append(val_loss)

            print(f"NO2训练损失: {train_loss:.6f}, NO2验证损失: {val_loss:.6f}, "
                  f"lr={self.optimizer.param_groups[0]['lr']:.2e}, "
                  f"zero_loss_batches={self.criterion.zero_loss_count}")

            if val_loss < self.best_val:
                self.best_val = val_loss
                self.best_state = {k: v.detach().cpu().clone() for k, v in self.model.state_dict().items()}
                print(f"🎯 新的最佳NO2验证损失: {val_loss:.6f}")

                # 保存最佳NO2模型到Google Drive
                import os
                os.makedirs("/content/drive/MyDrive/3DCNN_Pipeline/models", exist_ok=True)
                best_model_path = f"/content/drive/MyDrive/3DCNN_Pipeline/models/no2_3dcnn_best_model_epoch_{epoch+1}.pth"
                torch.save({
                    'model_state_dict': self.best_state,  # 用缓存的最佳权重
                    'epoch': epoch + 1,
                    'val_loss': val_loss,
                    'train_loss': train_loss,
                    'config': NO2_3DCNN_CONFIG
                }, best_model_path)
                print(f"💾 最佳NO2模型已保存到: {best_model_path}")

            self.scheduler.step(val_loss)

            if self.early_stopping(val_loss):
                print(f"🛑 NO2早停触发，在第 {epoch+1} 个epoch停止训练")
                break

        # 回滚到最优权重
        if self.best_state is not None:
            print(f"🔄 回滚到最优NO2权重 (验证损失: {self.best_val:.6f})")
            self.model.load_state_dict(self.best_state)

        # 保存最终NO2模型到Google Drive
        import os
        os.makedirs("/content/drive/MyDrive/3DCNN_Pipeline/models", exist_ok=True)
        model_save_path = "/content/drive/MyDrive/3DCNN_Pipeline/models/no2_3dcnn_model.pth"
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'best_val_loss': self.best_val,
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'config': NO2_3DCNN_CONFIG
        }, model_save_path)
        print(f"💾 NO2模型已保存到: {model_save_path}")

        print("✅ NO2训练完成!")
        return self.train_losses, self.val_losses

# ===== 早停类 =====
# [Step 17 / 步骤17] Early stopping 早停策略
class EarlyStopping:
    def __init__(self, patience=3, min_delta=0.0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float('inf')

    def __call__(self, val_loss):
        """
        # [Step 17.1 / 步骤17.1] Early stop decision 早停判定
        若验证损失未明显改善（小于 min_delta），计数器 +1；
        当计数器达到 patience 时，触发早停。

        If val loss does not improve by min_delta, increase counter. Stop when
        counter reaches patience.
        """
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1

        return self.counter >= self.patience

# ===== 主训练流程 =====
# [Step 18 / 步骤18] Main pipeline 主训练流程
def main():
    """
    训练入口 / Training entry point
    步骤 Steps:
    1) 构建训练/验证数据集与 DataLoader（含多进程与 pin_memory 优化）
    2) 初始化模型（通道数取决于数据集实际特征）
    3) 创建训练器（优化器、损失函数、调度器、AMP）
    4) 运行训练循环并保存最佳/最终模型
    5) 进行一次快速自检（前向+反向）以确认梯度与数值正常
    """
    print("🚀 NO2 3D CNN 最终修复版训练")
    print("=" * 60)

    # 创建NO2数据集
    print("📊 创建NO2 3D数据集...")
    # [Step 18.1 / 步骤18.1] Build training dataset 构建训练数据集
    train_dataset = NO2_3DCNN_Dataset(
        data_path=NO2_3DCNN_CONFIG['data_path'],
        scaler_path=NO2_3DCNN_CONFIG['scaler_path'],
        time_window=NO2_3DCNN_CONFIG['time_window'],
        train_years=NO2_3DCNN_CONFIG['train_years'],
        val_year=NO2_3DCNN_CONFIG['val_year'],
        test_year=NO2_3DCNN_CONFIG['test_year'],
        is_train=True,
        patch_size=NO2_3DCNN_CONFIG['patch_size'],
        patch_gap_ratio=NO2_3DCNN_CONFIG['patch_gap_ratio'],
        spatial_gap_ratio=NO2_3DCNN_CONFIG['spatial_gap_ratio'],
        min_valid_ratio=NO2_3DCNN_CONFIG['min_valid_ratio']
    )

    # [Step 18.2 / 步骤18.2] Build validation dataset 构建验证数据集
    val_dataset = NO2_3DCNN_Dataset(
        data_path=NO2_3DCNN_CONFIG['data_path'],
        scaler_path=NO2_3DCNN_CONFIG['scaler_path'],
        time_window=NO2_3DCNN_CONFIG['time_window'],
        train_years=NO2_3DCNN_CONFIG['train_years'],
        val_year=NO2_3DCNN_CONFIG['val_year'],
        test_year=NO2_3DCNN_CONFIG['test_year'],
        is_train=False,
        patch_size=NO2_3DCNN_CONFIG['patch_size'],
        patch_gap_ratio=NO2_3DCNN_CONFIG['patch_gap_ratio'],
        spatial_gap_ratio=NO2_3DCNN_CONFIG['spatial_gap_ratio'],
        min_valid_ratio=NO2_3DCNN_CONFIG['min_valid_ratio']
    )

    # [Step 18.3 / 步骤18.3] Create data loaders 创建数据加载器 (优化性能)
    train_loader = DataLoader(
        train_dataset,
        batch_size=NO2_3DCNN_CONFIG['batch_size'],
        shuffle=True,
        num_workers=4,  # 使用多进程加速数据加载
        pin_memory=(device.type == 'cuda'),
        persistent_workers=True  # 保持worker进程
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=NO2_3DCNN_CONFIG['batch_size'],
        shuffle=False,
        num_workers=4,  # 使用多进程加速数据加载
        pin_memory=(device.type == 'cuda'),
        persistent_workers=True  # 保持worker进程
    )

    print(f"✅ NO2 3D数据集创建完成")
    print(f"  训练样本: {len(train_dataset)}")
    print(f"  验证样本: {len(val_dataset)}")

    # [Step 18.4 / 步骤18.4] Create model 创建 NO2 模型（使用实际通道数）
    print("📊 创建NO2 3D CNN模型...")
    model = NO2_3DCNN_Model(
        input_channels=train_dataset.num_channels,  # 使用训练集的实际通道数
        out_in_01=False  # 不强制使用sigmoid
    )

    print(f"✅ NO2 3D CNN模型创建完成")
    print(f"  输入通道: {train_dataset.num_channels}")

    # [Step 18.5 / 步骤18.5] Create trainer 创建训练器
    print("📊 创建NO2训练器...")
    trainer = NO2_3DCNN_Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        learning_rate=NO2_3DCNN_CONFIG['learning_rate'],
        patience=NO2_3DCNN_CONFIG['patience']
    )

    # [Step 18.6 / 步骤18.6] Run training 开始训练
    print("🚀 开始NO2训练...")
    train_losses, val_losses = trainer.train(NO2_3DCNN_CONFIG['num_epochs'])

    print("🎉 NO2训练完成!")

    # [Step 18.7 / 步骤18.7] Quick self-check 快速自检
    print("\n🔍 执行快速自检...")
    try:
        # ---- 方式A: 直接可训练前向 + 反向 (最简单) ----
        xb, yb, mb = next(iter(train_loader))
        xb, yb, mb = xb.to(device), yb.to(device), mb.to(device)

        model.train()  # 确保有梯度
        out = model(xb)  # (B, 1, T, H, W)
        print("OUT:", out.shape)

        loss = trainer.criterion(out, yb, mb)
        loss.backward()  # 测试反向是否正常
        print("LOSS:", loss.item())
        print("✅ 快速自检通过!")

        # 可选:清空梯度,避免污染后续正式训练
        model.zero_grad(set_to_none=True)
    except Exception as e:
        print(f"❌ 快速自检失败: {e}")

    return model, trainer, None

# ===== 运行主函数 =====
if __name__ == "__main__":
    model, trainer, results = main()
