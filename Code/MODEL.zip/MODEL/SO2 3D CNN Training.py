# ===== SO2 3D CNN 训练（最终稳定版：通道对齐稳健 + 有效patch + AMP可选） =====
"""
SO2 3D CNN Final Stable Training Script

中文/English 双语说明 / Bilingual guide

本脚本提供 SO2 三维卷积网络完整训练流程，侧重于：
- 稳健的通道对齐（依据 scaler 名称与样本文件的 feature_names）
- 有效 patch 选择（验证阶段避免无监督样本）
- 可选 AMP 以提升 GPU 训练效率

This script trains a 3D CNN for SO2 with:
- Robust channel alignment using scaler names vs stack feature_names
- Valid patch selection on validation to ensure supervision exists
- Optional AMP for efficiency on CUDA
"""
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np, os, warnings
warnings.filterwarnings('ignore')

# [Step 0 / 步骤0] Device selection 选择设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🚀 使用设备: {device}")

# [Step 1 / 步骤1] Configure training config 配置训练参数
SO2_3DCNN_CONFIG = {
    'data_path': '/content/drive/MyDrive/Feature_Stacks',
    'scaler_path': '/content/drive/MyDrive/3DCNN_Pipeline/artifacts/scalers/SO2/meanstd_global_2019_2021.npz',
    'time_window': 7,
    'batch_size': 8,
    'num_epochs': 3,
    'learning_rate': 1e-4,
    'patience': 5,
    'train_years': [2019, 2020, 2021],
    'val_year': 2022,
    'test_year': 2023,
    'max_grad_norm': 1.0,
    'use_amp': False,  # 为避免 GradScaler 断言，默认关闭；需要可改 True
    'patch_size': 64,
    'patch_gap_ratio': 0.2,
    'spatial_gap_ratio': 0.15,
    'min_valid_ratio': 0.1,
    'mu_y': 4.658783e-05,
    'std_y': 3.376913e-04,
}
print('data_path:', SO2_3DCNN_CONFIG['data_path'])
print('scaler_path:', SO2_3DCNN_CONFIG['scaler_path'])

# 别名映射（scaler名 -> stack名）
# [Step 1.1 / 步骤1.1] Alias mapping for feature names 特征别名映射（scaler名 -> stack名）
ALIAS = {
    'lulc_01':'lulc_class_10','lulc_02':'lulc_class_20','lulc_03':'lulc_class_30','lulc_04':'lulc_class_40',
    'lulc_05':'lulc_class_50','lulc_06':'lulc_class_60','lulc_07':'lulc_class_70','lulc_08':'lulc_class_80',
    'lulc_09':'lulc_class_90','lulc_10':'lulc_class_100',
    'ssr':'ssr_clear','lag1':'so2_lag1','neighbor':'so2_neighbor'
}

def load_scaler_dicts(scaler_path):
    """
    [Step 2 / 步骤2] 加载scaler统计（通道顺序/均值/标准差）
    Load channel list with mean/std dicts from scaler npz.
    """
    with np.load(scaler_path, allow_pickle=True) as d:
        scaler_names = list(d['channel_list'].tolist())
        mean_dict = d['mean'].item()
        std_dict  = d['std'].item()
    return scaler_names, mean_dict, std_dict

def build_mapping_and_stats(sample_npz_path, scaler_names, mean_dict, std_dict):
    """
    [Step 3 / 步骤3] 构建通道对齐映射与标准化向量
    Build channel alignment from scaler names to stack indices, and create
    per-channel mean/std arrays aligned to the kept channels.
    """
    # 用一个样本文件的 feature_names 做“统一通道对齐”
    with np.load(sample_npz_path, allow_pickle=True) as data:
        stack_names = list(data['feature_names'].tolist())
    name_to_idx = {n:i for i,n in enumerate(stack_names)}
    kept_idx, kept_names, kept_means, kept_stds, warned, dropped = [], [], [], [], [], []
    for s in scaler_names:
        cand = s if s in name_to_idx else ALIAS.get(s, None)
        if cand in name_to_idx:
            kept_idx.append(name_to_idx[cand]); kept_names.append(s)
            m = mean_dict.get(s, 0.0); sd = std_dict.get(s, 1.0)
            if (s not in mean_dict) or (s not in std_dict): warned.append(s)
            if not np.isfinite(sd) or sd <= 0: sd = 1.0
            kept_means.append(float(m)); kept_stds.append(float(sd))
        else:
            dropped.append((s, cand))
    if warned:  print(f"⚠️ 无统计(已用默认0/1): {warned}")
    if dropped: print(f"⚠️ 在stack中缺失(已丢弃): {dropped}")
    return (np.asarray(kept_idx, dtype=np.int64),
            kept_names,
            np.asarray(kept_means, dtype=np.float32),
            np.asarray(kept_stds,  dtype=np.float32))

def pick_valid_patch(y, m, patch_size=64, last_frame_only=True, min_valid=50):
    """
    [Step 4 / 步骤4] 在验证/测试阶段从网格中选择一个具有足够监督像素的patch
    Pick a patch location that has at least `min_valid` supervised pixels.
    """
    T,H,W = y.shape
    step = patch_size
    for sh in range(0, max(1, H-patch_size+1), step):
        for sw in range(0, max(1, W-patch_size+1), step):
            ys = y[:, sh:sh+patch_size, sw:sw+patch_size]
            ms = m[:, sh:sh+patch_size, sw:sw+patch_size]
            valid = (ms[-1] if last_frame_only else ms).sum()
            if valid >= min_valid:
                return sh, sw
    return max(0,H//2 - patch_size//2), max(0,W//2 - patch_size//2)

class SO2_3DCNN_Dataset(Dataset):
    """
    [Step 5 / 步骤5] SO2 数据集（时间窗口 + 空间patch + 标准化 + 缺口增强）

    - 构建时间窗口（滑动）并按需注入时间/空间缺口（仅训练）
    - 依据 scaler 名称与样本 feature_names 做通道对齐，并准备 mean/std
    - 训练阶段随机 patch；验证阶段选择具备最小监督像素的 patch

    Dataset building temporal windows; applies gaps during training, standardizes
    features using per-channel mean/std, and ensures supervised validation patches.
    """
    def __init__(self, data_path, scaler_path, time_window=7,
                 train_years=[2019, 2020, 2021], val_year=2022, test_year=2023,
                 is_train=True, patch_size=64, patch_gap_ratio=0.2,
                 spatial_gap_ratio=0.15, min_valid_ratio=0.1):
        self.data_path = data_path
        self.time_window = time_window
        self.is_train = is_train
        self.H, self.W = 300, 621
        self.patch_size = patch_size
        self.patch_gap_ratio = patch_gap_ratio
        self.spatial_gap_ratio = spatial_gap_ratio
        self.min_valid_ratio = min_valid_ratio

        # [Step 5.1 / 步骤5.1] 列出各年文件清单 / enumerate files per year
        self.train_files, self.val_files, self.test_files = [], [], []
        for y in train_years:
            ydir = os.path.join(data_path, f'SO2_{y}')
            if os.path.exists(ydir):
                fs = sorted([os.path.join(ydir,f) for f in os.listdir(ydir) if f.startswith('SO2_stack_') and f.endswith('.npz')])
                self.train_files += fs
        for y in [val_year, test_year]:
            ydir = os.path.join(data_path, f'SO2_{y}')
            if os.path.exists(ydir):
                fs = sorted([os.path.join(ydir,f) for f in os.listdir(ydir) if f.startswith('SO2_stack_') and f.endswith('.npz')])
                (self.val_files if y==val_year else self.test_files).extend(fs)

        # [Step 5.2 / 步骤5.2] 选择当前模式的文件列表 / choose mode file list
        self.file_list = self.train_files if self.is_train else (self.val_files if len(self.val_files)>0 else self.test_files)
        if len(self.file_list) < time_window:
            raise RuntimeError(f"文件不足: {len(self.file_list)} < time_window={time_window}")
        # [Step 5.3 / 步骤5.3] 构建时间窗口起点索引 / valid window starts
        self.valid_windows = list(range(len(self.file_list) - time_window + 1))

        # [Step 5.4 / 步骤5.4] 通道对齐与统计准备（构建一次）
        scaler_names, mean_dict, std_dict = load_scaler_dicts(scaler_path)
        sample_npz = self.file_list[0]
        kept_idx, kept_names, means_np, stds_np = build_mapping_and_stats(sample_npz, scaler_names, mean_dict, std_dict)
        self.kept_idx = kept_idx
        self.num_channels = len(kept_names)
        self.means_t = torch.tensor(means_np, dtype=torch.float32).view(1, -1, 1, 1)
        self.stds_t  = torch.tensor(stds_np,  dtype=torch.float32).view(1, -1, 1, 1)

        print(f"✅ 数据集就绪: is_train={self.is_train}, T={self.time_window}, C={self.num_channels}, 窗口数={len(self.valid_windows)}")

    def __len__(self): return len(self.valid_windows)

    def _load_single_file(self, path):
        """
        [Step 6 / 步骤6] 加载单日栈并对齐空间尺寸与通道顺序
        Load a daily stack and align to (H,W) and channel order using kept_idx.
        Returns X(C,H,W), y(H,W), m(H,W).
        """
        with np.load(path, allow_pickle=True) as d:
            X = d['X']            # (C,H,W)
            y = d['y']            # (H,W)
            m = d['mask'].astype(bool)
        if X.shape[1:] != (self.H, self.W):
            X2 = np.full((X.shape[0], self.H, self.W), np.nan, dtype=np.float32)
            h = min(self.H, X.shape[1]); w = min(self.W, X.shape[2])
            X2[:, :h, :w] = X[:, :h, :w]; X = X2
            y2 = np.full((self.H, self.W), np.nan, dtype=np.float32); y2[:h,:w]=y[:h,:w]; y=y2
            m2 = np.zeros((self.H, self.W), dtype=bool); m2[:h,:w]=m[:h,:w]; m=m2
        X = X[self.kept_idx]  # 统一重排
        return X.astype(np.float32), y.astype(np.float32), m

    def __getitem__(self, idx):
        """
        [Step 7 / 步骤7] 组装一个样本：加载时间窗口 -> 缺口增强(训练) -> 取patch -> 标准化 -> 标签
        Assemble one sample: load window -> gaps (train) -> patch -> standardize -> labels
        """
        s = self.valid_windows[idx]
        Xs, Ys, Ms = [], [], []
        for i in range(self.time_window):
            X, y, m = self._load_single_file(self.file_list[s+i])
            Xs.append(X); Ys.append(y); Ms.append(m)
        X = np.stack(Xs, axis=0)   # (T,C,H,W)
        y = np.stack(Ys, axis=0)   # (T,H,W)
        m = np.stack(Ms, axis=0)   # (T,H,W)

        # [Step 7.1 / 步骤7.1] 人工缺口（仅训练）/ synthetic gaps (train only)
        if self.is_train:
            X, y, m = self._apply_gaps(X, y, m)

        # [Step 7.2 / 步骤7.2] 取patch（验证期需保证监督像素足够）
        if self.is_train:
            sh = np.random.randint(0, max(1, self.H - self.patch_size) + 1)
            sw = np.random.randint(0, max(1, self.W - self.patch_size) + 1)
        else:
            sh, sw = pick_valid_patch(y, m, self.patch_size, last_frame_only=True,
                                      min_valid=max(1, int(0.01*self.patch_size*self.patch_size)))
        eh, ew = min(self.H, sh+self.patch_size), min(self.W, sw+self.patch_size)
        X = X[:, :, sh:eh, sw:ew]; y = y[:, sh:eh, sw:ew]; m = m[:, sh:eh, sw:ew]

        # [Step 7.3 / 步骤7.3] 标准化特征与目标 / standardization
        Xt = torch.from_numpy(X).float()
        Xt = torch.nan_to_num(Xt, 0.0, 0.0, 0.0)
        Xt = (Xt - self.means_t) / self.stds_t

        yt = torch.from_numpy(y).float()
        mt = torch.from_numpy(m).bool()
        yt[~mt] = 0.0
        mu_y, std_y = SO2_3DCNN_CONFIG['mu_y'], SO2_3DCNN_CONFIG['std_y']
        yt = (yt - mu_y) / max(std_y, 1e-8)

        # [Step 7.4 / 步骤7.4] 构建损失用标签（-999屏蔽无效）
        y_for_loss = yt.clone()
        y_for_loss[~mt] = -999.0
        return Xt, y_for_loss, mt

    def _apply_gaps(self, X, y, m):
        """
        [Step 8 / 步骤8] 缺口增强：时间与空间（不影响最后一帧监督）
        Apply temporal and spatial gaps for augmentation (excluding last frame).
        """
        T,C,H,W = X.shape
        last = T-1
        Xg, yg, mg = X.copy(), y.copy(), m.copy()
        n_time = int(T * SO2_3DCNN_CONFIG['patch_gap_ratio'])
        if n_time > 0 and last > 0:
            idx = np.random.choice(np.arange(0,last), size=min(n_time,last), replace=False)
            Xg[idx] = np.nan; yg[idx] = np.nan; mg[idx] = False
        n_sp = int(H*W*SO2_3DCNN_CONFIG['spatial_gap_ratio'])
        if n_sp > 0 and last > 0:
            ti = np.random.randint(0, last, size=n_sp)
            hi = np.random.randint(0, H, size=n_sp)
            wi = np.random.randint(0, W, size=n_sp)
            Xg[ti, :, hi, wi] = np.nan
            yg[ti,    hi, wi] = np.nan
            mg[ti,    hi, wi] = False
        return Xg, yg, mg

class SO2_3DCNN_Model(nn.Module):
    """
    [Step 9 / 步骤9] 3D CNN 模型：3个卷积块 + GroupNorm + ReLU + 1x1x1 头
    适配输入 (B,T,C,H,W)，前向内部转为 (B,C,T,H,W)。
    """
    def __init__(self, input_channels=30, out_in_01=False):
        super().__init__()
        self.out_in_01 = out_in_01
        ch = 32
        self.body = nn.Sequential(
            nn.Conv3d(input_channels, ch, 3, padding=1),
            nn.GroupNorm(8, ch),
            nn.ReLU(inplace=True),
            nn.Conv3d(ch, ch*2, 3, padding=1),
            nn.GroupNorm(8, ch*2),
            nn.ReLU(inplace=True),
            nn.Conv3d(ch*2, ch*4, 3, padding=1),
            nn.GroupNorm(8, ch*4),
            nn.ReLU(inplace=True),
        )
        self.head = nn.Conv3d(ch*4, 1, 1)
    def forward(self, x):           # x: (B,T,C,H,W)
        """
        [Step 9.1 / 步骤9.1] 前向传播：重排为 (B,C,T,H,W) -> 主干 -> 头
        Forward pass: permute to (B,C,T,H,W) -> body -> head -> optional sigmoid
        """
        x = x.permute(0,2,1,3,4)    # (B,C,T,H,W)
        x = self.body(x)
        x = self.head(x)
        if self.out_in_01: x = torch.sigmoid(x)
        return x                    # (B,1,T,H,W)

class SO2_3DCNN_Loss(nn.Module):
    """
    [Step 10 / 步骤10] 损失：带掩码的 MSE（默认仅监督最后一帧）
    Masked MSE; supervise last frame by default.
    """
    def __init__(self, supervise_last_frame_only=True, min_valid_ratio=0.01):
        super().__init__()
        self.supervise_last_frame_only = supervise_last_frame_only
        self.min_valid_ratio = min_valid_ratio
        self.zero_loss_count = 0
    def forward(self, pred, target, mask):
        """
        [Step 10.1 / 步骤10.1] 根据掩码与 -999 过滤无效像素并计算 MSE
        Filter invalid via mask and -999 sentinel, then compute MSE.
        """
        pred = pred.squeeze(1)      # (B,T,H,W)
        if self.supervise_last_frame_only:
            p, t, m = pred[:, -1], target[:, -1], mask[:, -1]
        else:
            p, t, m = pred, target, mask
        valid = torch.isfinite(t) & (t != -999.0) & m
        if valid.float().mean().item() < self.min_valid_ratio or valid.sum() == 0:
            self.zero_loss_count += 1
            return torch.tensor(1e-6, device=pred.device, requires_grad=True)
        return F.mse_loss(p[valid], t[valid])

class EarlyStopping:
    """
    [Step 11 / 步骤11] 早停：若验证损失未改善超过 min_delta，则累计计数；达到 patience 停止。
    Early stopping: stop when no improvement by min_delta for `patience` epochs.
    """
    def __init__(self, patience=3, min_delta=0.0):
        self.patience, self.min_delta = patience, min_delta
        self.counter, self.best = 0, float('inf')
    def __call__(self, val_loss):
        if val_loss < self.best - self.min_delta:
            self.best, self.counter = val_loss, 0
        else:
            self.counter += 1
        return self.counter >= self.patience

class SO2_3DCNN_Trainer:
    """
    [Step 12 / 步骤12] 训练器：封装训练/验证过程、调度器、AMP、早停与模型保存
    Trainer encapsulating train/val, LR scheduling, AMP, early stopping, saving.
    """
    def __init__(self, model, train_loader, val_loader, device, learning_rate=1e-4, patience=5):
        self.model = model.to(device)
        self.train_loader, self.val_loader, self.device = train_loader, val_loader, device
        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate, weight_decay=1e-6)
        self.criterion = SO2_3DCNN_Loss(supervise_last_frame_only=True, min_valid_ratio=SO2_3DCNN_CONFIG['min_valid_ratio'])
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, mode='min', patience=2, factor=0.5)
        self.early_stopping = EarlyStopping(patience=patience)
        self.use_amp = SO2_3DCNN_CONFIG.get('use_amp', False) and (device.type=='cuda')
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.use_amp)
        self.best_val, self.best_state = float('inf'), None
        self.train_losses, self.val_losses = [], []
    def train_one_epoch(self):
        """
        [Step 12.1 / 步骤12.1] 训练一个 epoch：支持 AMP 与梯度裁剪
        Train for one epoch with optional AMP and gradient clipping.
        """
        self.model.train()
        total, steps = 0.0, 0
        for bi,(X,y,m) in enumerate(self.train_loader):
            X,y,m = X.to(self.device), y.to(self.device), m.to(self.device)
            self.optimizer.zero_grad(set_to_none=True)
            if self.use_amp:
                with torch.cuda.amp.autocast(enabled=True):
                    pred = self.model(X)
                    loss = self.criterion(pred, y, m)
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), SO2_3DCNN_CONFIG['max_grad_norm'])
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                pred = self.model(X)
                loss = self.criterion(pred, y, m)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), SO2_3DCNN_CONFIG['max_grad_norm'])
                self.optimizer.step()
            total += loss.item(); steps += 1
            if bi == 0: print(f"  batch0: X{tuple(X.shape)} pred{tuple(pred.shape)} loss={loss.item():.6f}")
        return total / max(steps,1)
    def validate_one_epoch(self):
        """
        [Step 12.2 / 步骤12.2] 验证一个 epoch：仅前向与损失计算
        Validate for one epoch (no grads).
        """
        self.model.eval()
        total, steps = 0.0, 0
        with torch.no_grad():
            for X,y,m in self.val_loader:
                X,y,m = X.to(self.device), y.to(self.device), m.to(self.device)
                pred = self.model(X)
                loss = self.criterion(pred, y, m)
                total += loss.item(); steps += 1
        return total / max(steps,1)
    def train(self, num_epochs):
        """
        [Step 12.3 / 步骤12.3] 完整训练循环与保存最佳模型
        Full training loop with best checkpoint saving.
        """
        print(f"🚀 开始训练 {num_epochs} epochs")
        for ep in range(num_epochs):
            print(f"\nEpoch {ep+1}/{num_epochs}")
            tr = self.train_one_epoch(); va = self.validate_one_epoch()
            self.train_losses.append(tr); self.val_losses.append(va)
            print(f" train_loss={tr:.6f}  val_loss={va:.6f}")
            if va < self.best_val:
                self.best_val, self.best_state = va, {k:v.detach().cpu().clone() for k,v in self.model.state_dict().items()}
                os.makedirs("/content/drive/MyDrive/3DCNN_Pipeline/models", exist_ok=True)
                torch.save({'model_state_dict': self.best_state, 'epoch': ep+1, 'val_loss': va, 'config': SO2_3DCNN_CONFIG},
                           f"/content/drive/MyDrive/3DCNN_Pipeline/models/so2_3dcnn_best_model_epoch_{ep+1}.pth")
                print("  💾 保存最佳权重")
            self.scheduler.step(va)
            if self.early_stopping(va):
                print("🛑 早停触发"); break
        if self.best_state is not None: self.model.load_state_dict(self.best_state)
        os.makedirs("/content/drive/MyDrive/3DCNN_Pipeline/models", exist_ok=True)
        torch.save({'model_state_dict': self.model.state_dict(),'best_val_loss': self.best_val,
                    'train_losses': self.train_losses,'val_losses': self.val_losses,'config': SO2_3DCNN_CONFIG},
                   "/content/drive/MyDrive/3DCNN_Pipeline/models/so2_3dcnn_model.pth")
        print("✅ 训练完成"); return self.train_losses, self.val_losses

def main():
    """
    [Step 13 / 步骤13] 主流程：构建数据集/加载器 -> 模型 -> 训练器 -> 训练
    Main entry: build datasets/loaders -> model -> trainer -> train
    """
    train_dataset = SO2_3DCNN_Dataset(
        data_path=SO2_3DCNN_CONFIG['data_path'],
        scaler_path=SO2_3DCNN_CONFIG['scaler_path'],
        time_window=SO2_3DCNN_CONFIG['time_window'],
        train_years=SO2_3DCNN_CONFIG['train_years'],
        val_year=SO2_3DCNN_CONFIG['val_year'],
        test_year=SO2_3DCNN_CONFIG['test_year'],
        is_train=True,
        patch_size=SO2_3DCNN_CONFIG['patch_size'],
        patch_gap_ratio=SO2_3DCNN_CONFIG['patch_gap_ratio'],
        spatial_gap_ratio=SO2_3DCNN_CONFIG['spatial_gap_ratio'],
        min_valid_ratio=SO2_3DCNN_CONFIG['min_valid_ratio']
    )
    val_dataset = SO2_3DCNN_Dataset(
        data_path=SO2_3DCNN_CONFIG['data_path'],
        scaler_path=SO2_3DCNN_CONFIG['scaler_path'],
        time_window=SO2_3DCNN_CONFIG['time_window'],
        train_years=SO2_3DCNN_CONFIG['train_years'],
        val_year=SO2_3DCNN_CONFIG['val_year'],
        test_year=SO2_3DCNN_CONFIG['test_year'],
        is_train=False,
        patch_size=SO2_3DCNN_CONFIG['patch_size'],
        patch_gap_ratio=SO2_3DCNN_CONFIG['patch_gap_ratio'],
        spatial_gap_ratio=SO2_3DCNN_CONFIG['spatial_gap_ratio'],
        min_valid_ratio=SO2_3DCNN_CONFIG['min_valid_ratio']
    )
    # [Step 13.1 / 步骤13.1] DataLoaders（可按平台调节 num_workers）
    # Colab 更稳：num_workers=0
    train_loader = DataLoader(train_dataset, batch_size=SO2_3DCNN_CONFIG['batch_size'],
                              shuffle=True, num_workers=8, pin_memory=(device.type=='cuda'))
    val_loader   = DataLoader(val_dataset, batch_size=SO2_3DCNN_CONFIG['batch_size'],
                              shuffle=False, num_workers=8, pin_memory=(device.type=='cuda'))

    # [Step 13.2 / 步骤13.2] 构建模型（通道数来源于数据集映射）
    model = SO2_3DCNN_Model(input_channels=train_dataset.num_channels, out_in_01=False)
    # [Step 13.3 / 步骤13.3] 创建训练器并启动训练
    trainer = SO2_3DCNN_Trainer(model, train_loader, val_loader, device,
                                learning_rate=SO2_3DCNN_CONFIG['learning_rate'],
                                patience=SO2_3DCNN_CONFIG['patience'])
    return trainer.train(SO2_3DCNN_CONFIG['num_epochs'])

if __name__ == "__main__":
    train_losses, val_losses = main()