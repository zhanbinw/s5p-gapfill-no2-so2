# ===== SO2 3D CNN Masked Validation (random/block + monthly + sensitive-channel masking) =====
"""
SO2 3D CNN Masked Validation Runner

中文/English 双语说明 / Bilingual guide

对已训练 SO2 3D CNN 进行遮挡验证：
- 随机像素或块状遮挡（random/block）
- 可选按月份子集评估
- 可选屏蔽敏感通道（如 neighbor）

Evaluate a trained SO2 3D CNN with masked validation:
- Random pixel or block-wise masking
- Optional monthly subset
- Optional sensitive-channel masking (e.g., neighbor)
"""
import numpy as np, os, re, torch
import torch.nn as nn
from numpy.random import default_rng

# -------- Paths & basic config --------
# [Step 1 / 步骤1] 基础路径与参数 / Base paths and params
BASE = "/content/drive/MyDrive"
CKPT = f"{BASE}/3DCNN_Pipeline/models/so2_3dcnn_model.pth"  # 或替换为 best_model 路径
STACK_19 = f"{BASE}/Feature_Stacks/SO2_2019"
STACK_20 = f"{BASE}/Feature_Stacks/SO2_2020"
STACK_21 = f"{BASE}/Feature_Stacks/SO2_2021"
STACK_22 = f"{BASE}/Feature_Stacks/SO2_2022"
STACK_23 = f"{BASE}/Feature_Stacks/SO2_2023"
SCALER    = f"{BASE}/3DCNN_Pipeline/artifacts/scalers/SO2/meanstd_global_2019_2021.npz"

TIME_WINDOW = 7   # [Step 1.1 / 步骤1.1] 时间窗口长度 / temporal window length
H, W = 300, 621
mu_y  = 4.658783e-05
std_y = 3.376913e-04
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# -------- What to evaluate --------
# [Step 2 / 步骤2] 配置评估场景 / Evaluation scenarios
EVALS = [
    {"name":"all_random_pixel",        "mode":"random_pixel", "ratio":0.2, "block":32, "months":None, "mask_sensitive":False},
    {"name":"all_block32",             "mode":"block",        "ratio":0.2, "block":32, "months":None, "mask_sensitive":False},
    {"name":"all_block32_maskNeighbor","mode":"block",        "ratio":0.2, "block":32, "months":None, "mask_sensitive":True},
    {"name":"Mar_block32",             "mode":"block",        "ratio":0.2, "block":32, "months":[3],  "mask_sensitive":False},
]
REPEATS     = 3
MAX_WINDOWS = 300         # 每个设置最多评估的日窗口数（None=全量）
MIN_HOLD    = 200         # 每天最少采样的held-out像素数下限

# -------- Model (match training) --------
# [Step 3 / 步骤3] 与训练一致的模型结构 / Model matching training
class SO2_3DCNN_Model(nn.Module):
    def __init__(self, input_channels=30, out_in_01=False):
        super().__init__()
        self.out_in_01 = out_in_01
        ch = 32
        self.body = nn.Sequential(
            nn.Conv3d(input_channels, ch, 3, padding=1), nn.GroupNorm(8, ch),    nn.ReLU(inplace=True),
            nn.Conv3d(ch, ch*2, 3, padding=1),           nn.GroupNorm(8, ch*2),  nn.ReLU(inplace=True),
            nn.Conv3d(ch*2, ch*4, 3, padding=1),         nn.GroupNorm(8, ch*4),  nn.ReLU(inplace=True),
        )
        self.head = nn.Conv3d(ch*4, 1, 1)
    def forward(self, x):                # x: (B,T,C,H,W)
        """
        [Step 3.1 / 步骤3.1] 前向传播：重排为 (B,C,T,H,W) -> 主干 -> 头
        Forward pass: permute to (B,C,T,H,W) -> body -> head
        """
        x = x.permute(0,2,1,3,4)         # -> (B,C,T,H,W)
        return self.head(self.body(x))   # (B,1,T,H,W)

# -------- Scaler & channel mapping (same as training) --------
# [Step 4 / 步骤4] 加载scaler与通道映射 / Load scaler and build channel mapping
ALIAS = {
    'lulc_01':'lulc_class_10','lulc_02':'lulc_class_20','lulc_03':'lulc_class_30','lulc_04':'lulc_class_40',
    'lulc_05':'lulc_class_50','lulc_06':'lulc_class_60','lulc_07':'lulc_class_70','lulc_08':'lulc_class_80',
    'lulc_09':'lulc_class_90','lulc_10':'lulc_class_100',
    'ssr':'ssr_clear','lag1':'so2_lag1','neighbor':'so2_neighbor'
}
with np.load(SCALER, allow_pickle=True) as d:
    scaler_names = list(d['channel_list'].tolist())
    mean_dict    = d['mean'].item()
    std_dict     = d['std'].item()

def build_mapping_and_stats(sample_npz_path):
    """
    [Step 4.1 / 步骤4.1] 依据样本文件的 feature_names 统一通道顺序，并获取均值/标准差
    Align channels to scaler_names via alias mapping; compute means/stds arrays.
    """
    with np.load(sample_npz_path, allow_pickle=True) as data:
        stack_names = list(data['feature_names'].tolist())
    name_to_idx = {n:i for i,n in enumerate(stack_names)}
    kept_idx, kept_names, kept_means, kept_stds, warned, dropped = [], [], [], [], [], []
    for s in scaler_names:
        cand = s if s in name_to_idx else ALIAS.get(s, None)
        if cand in name_to_idx:
            kept_idx.append(name_to_idx[cand]); kept_names.append(s)
            m = mean_dict.get(s, 0.0); sd = std_dict.get(s, 1.0)
            if (s not in mean_dict) or (s not in std_dict): warned.append(s)
            if not np.isfinite(sd) or sd <= 0: sd = 1.0
            kept_means.append(float(m)); kept_stds.append(float(sd))
        else:
            dropped.append((s, cand))
    if warned:  print("⚠️ 无统计(已用默认0/1):", warned)
    if dropped: print("⚠️ 在stack中缺失(已丢弃):", dropped)
    return (np.asarray(kept_idx, np.int64),
            kept_names,
            np.asarray(kept_means, np.float32),
            np.asarray(kept_stds,  np.float32))

# -------- Datasets & file lists --------
# [Step 5 / 步骤5] 列出各年份文件与月份解析 / List files and parse months
def list_year(dir_path):
    return sorted([os.path.join(dir_path,f) for f in os.listdir(dir_path) if f.endswith('.npz')]) if os.path.exists(dir_path) else []

files_19 = list_year(STACK_19)
files_20 = list_year(STACK_20)
files_21 = list_year(STACK_21)
files_22 = list_year(STACK_22)
files_23 = list_year(STACK_23)

files_hist = files_19 + files_20 + files_21 + files_22  # 用于 2023 年窗口的历史部分
files_2023 = files_23

def filename_month(fp):
    """
    [Step 5.1 / 步骤5.1] 从文件名解析月份（SO2_stack_YYYYMMDD.npz）
    Parse month from filename.
    """
    m = re.search(r'(\d{8})', os.path.basename(fp))
    if not m: return None
    return int(m.group(1)[4:6])

months_23 = [filename_month(fp) for fp in files_2023]

def filter_day_indices(months):
    """
    [Step 5.2 / 步骤5.2] 依据月份过滤 2023 天索引 / Filter 2023 day indices by months
    """
    idx_all = list(range(len(files_2023)))
    if not months: return idx_all
    ms = set(months)
    return [i for i,mm in enumerate(months_23) if mm in ms]

# 统一通道映射：基于第一个可用文件
sample_npz_for_mapping = next((p for p in (files_2023 or files_22 or files_hist) if os.path.exists(p)), None)
kept_idx, kept_names, means_np, stds_np = build_mapping_and_stats(sample_npz_for_mapping)
C = len(kept_names)

# -------- Load one window (T,C,H,W) + last-day y/mask --------
# [Step 6 / 步骤6] 生成时间窗口文件序列并加载 / Build window paths and load
def window_paths(day_idx):
    # day_idx 对应 2023 的第 day_idx 天（最后一帧），向前 TIME_WINDOW-1 拼接历史（2019-2022 + 2023）
    paths=[]
    for t in range(TIME_WINDOW):
        j = day_idx - (TIME_WINDOW-1) + t
        if j < 0:
            k = len(files_hist) + j
            paths.append(files_hist[k] if 0 <= k < len(files_hist) else None)
        elif j < len(files_2023):
            paths.append(files_2023[j])
        else:
            paths.append(None)
    return paths

def load_window(day_idx):
    """
    [Step 7 / 步骤7] 加载时间窗口：通道对齐、空间裁切、标准化
    Load temporal window with channel alignment, spatial fit, and standardization.
    """
    paths = window_paths(day_idx)
    Xs, Ys, Ms = [], [], []
    for p in paths:
        if (p is None) or (not os.path.exists(p)):
            Xs.append(np.zeros((C,H,W), np.float32))
            Ys.append(np.full((H,W), np.nan, np.float32))
            Ms.append(np.zeros((H,W), dtype=bool))
            continue
        with np.load(p, allow_pickle=True) as d:
            X = d['X']            # (C_all,H,W)
            y = d['y'].astype(np.float32)
            m = d['mask'].astype(bool)
            # 对齐 & 裁切
            X = X[kept_idx]
            if X.shape[1:] != (H,W):
                X2 = np.full((X.shape[0],H,W), np.nan, np.float32)
                hh=min(H,X.shape[1]); ww=min(W,X.shape[2])
                X2[:, :hh, :ww] = X[:, :hh, :ww]; X = X2
                y2 = np.full((H,W), np.nan, np.float32); y2[:hh,:ww]=y[:hh,:ww]; y=y2
                m2 = np.zeros((H,W), dtype=bool); m2[:hh,:ww]=m[:hh,:ww]; m=m2
            # 标准化（与训练一致）：nan->0 再 (x-mean)/std
            # [Step 7.1 / 步骤7.1] 标准化特征 / Feature standardization
            X = np.nan_to_num(X, nan=0.0)
            X = (X - means_np[:,None,None]) / (stds_np[:,None,None] + 1e-12)
            Xs.append(X.astype(np.float32)); Ys.append(y); Ms.append(m)
    X = np.stack(Xs, axis=0)   # (T,C,H,W)
    y = np.stack(Ys, axis=0)   # (T,H,W)
    m = np.stack(Ms, axis=0)   # (T,H,W)
    return X, y, m

# -------- Holdout & metrics --------
# [Step 8 / 步骤8] 构造 holdout 与计算指标 / Holdout masking and metrics
def make_holdout(valid, mode="random_pixel", ratio=0.2, block=32, rng=None):
    if rng is None: rng = default_rng(2025)
    h,w = valid.shape
    hold = np.zeros_like(valid, dtype=bool)
    if mode=="random_pixel":
        idx = np.argwhere(valid)
        if len(idx)==0: return hold
        k = max(1, int(len(idx)*ratio))
        sel = idx[rng.choice(len(idx), k, replace=False)]
        hold[sel[:,0], sel[:,1]] = True
    else:
        target = int(h*w*ratio); covered=0; tries=0
        while covered<target and tries<2000:
            y0 = rng.integers(0, max(1,h-block+1)); x0 = rng.integers(0, max(1,w-block+1))
            patch = np.zeros_like(hold); patch[y0:y0+block, x0:x0+block]=True
            new = patch & valid & (~hold); c=int(new.sum())
            if c>0: hold[new]=True; covered+=c
            tries+=1
    return hold & valid

def compute_metrics(y_true, y_pred):
    """
    [Step 8.1 / 步骤8.1] 常用回归指标：RMSE/MAE/R²/相关/偏差/NRMSE
    Common regression metrics.
    """
    y_true = y_true.astype(np.float64); y_pred = y_pred.astype(np.float64)
    rmse = float(np.sqrt(np.mean((y_true - y_pred)**2)))
    mae  = float(np.mean(np.abs(y_true - y_pred)))
    denom = np.sum((y_true - np.mean(y_true))**2) + 1e-12
    r2 = float(1.0 - np.sum((y_true - y_pred)**2)/denom) if denom>0 else np.nan
    corr = float(np.corrcoef(y_true, y_pred)[0,1]) if (np.std(y_true)>0 and np.std(y_pred)>0) else np.nan
    bias = float(np.mean(y_pred - y_true))
    nrmse_std   = rmse / (np.std(y_true) + 1e-12)
    nrmse_range = rmse / (np.max(y_true)-np.min(y_true) + 1e-12)
    return {"rmse":rmse,"mae":mae,"r2":r2,"corr":corr,"bias":bias,"nrmse_std":nrmse_std,"nrmse_range":nrmse_range}

def print_compact(title, m, n):
    """
    [Step 8.2 / 步骤8.2] 紧凑打印指标摘要 / Compact summary printer
    """
    print(f"{title} | n={n:,} | RMSE={m['rmse']:.6f} | NRMSE_std={m['nrmse_std']:.4f} | "
          f"NRMSE_range={m['nrmse_range']:.4f} | MAE={m['mae']:.6f} | R²={m['r2']:.4f} | "
          f"Corr={m['corr']:.4f} | Bias={m['bias']:.6f}")

def sensitive_channel_indices():
    """
    [Step 9 / 步骤9] 收集敏感通道索引（如果存在）
    Collect indices of sensitive channels if present.
    """
    # 仅当 scaler_names 中包含 'neighbor' 时有效
    idxs=[]
    if 'neighbor' in scaler_names:
        idxs.append(scaler_names.index('neighbor'))
    return idxs

# -------- Load model --------
# [Step 10 / 步骤10] 加载模型并设为评估模式 / Load checkpoint and eval mode
model = SO2_3DCNN_Model(input_channels=C).to(device)
state = torch.load(CKPT, map_location=device)
state = state.get('model_state_dict', state)
model.load_state_dict(state)
model.eval()

# -------- Runner --------
# [Step 11 / 步骤11] 运行评估配置 / Run one evaluation config
def run_eval(eval_cfg):
    name = eval_cfg["name"]; mode = eval_cfg["mode"]; ratio = eval_cfg["ratio"]; block = eval_cfg["block"]
    months = eval_cfg.get("months"); mask_sensitive = eval_cfg.get("mask_sensitive", False)

    day_indices = filter_day_indices(months)
    if MAX_WINDOWS is not None:
        day_indices = day_indices[:MAX_WINDOWS]

    rng = default_rng(2026)
    sens_idx = sensitive_channel_indices() if mask_sensitive else []
    runs=[]

    for rep in range(REPEATS):
        ys, ps = [], []
        for di in day_indices:
            X, y, m = load_window(di)
            valid = m[-1]
            if valid.sum()<MIN_HOLD: 
                continue
            hold = make_holdout(valid, mode, ratio, block, rng)
            if hold.sum()<MIN_HOLD:
                continue

            Xt = torch.from_numpy(X).unsqueeze(0).to(device)  # (1,T,C,H,W)
            hold_t = torch.from_numpy(hold).to(device)

            # 将被遮挡位置全部置零（所有T、所有C），与“缺失”一致
            # [Step 11.1 / 步骤11.1] 应用 holdout 遮挡到所有时间与通道 / Apply holdout mask to all T,C
            Xt[:, :, :, hold_t] = 0.0
            # 可选：再额外屏蔽敏感通道（如 neighbor）
            # [Step 11.2 / 步骤11.2] 可选：屏蔽敏感通道 / Optional sensitive channel masking
            for ci in sens_idx:
                Xt[:, :, ci, hold_t] = 0.0

            with torch.no_grad():
                pred = model(Xt)                  # (1,1,T,H,W)
                pred_last = pred[:,0,-1]*std_y + mu_y
            y_true = y[-1]; y_pred = pred_last[0].detach().cpu().numpy()

            ys.append(y_true[hold]); ps.append(y_pred[hold])

        if ys:
            y_all = np.concatenate(ys,0); p_all = np.concatenate(ps,0)
            mtr = compute_metrics(y_all, p_all)
            runs.append((mtr, len(y_all)))
            print_compact(f"{name} - run {rep+1} ({mode})", mtr, len(y_all))
        else:
            print(f"{name} - run {rep+1}: no held-out collected")

    if runs:
        mets = [r[0] for r in runs]; ns = [r[1] for r in runs]
        mean = {k: float(np.mean([m[k] for m in mets])) for k in mets[0]}
        std  = {k: float(np.std( [m[k] for m in mets])) for k in mets[0]}
        print_compact(f"{name} - mean", mean, int(np.mean(ns)))
        print(f"(±1σ) RMSE={std['rmse']:.6f} | NRMSE_std={std['nrmse_std']:.4f} | "
              f"NRMSE_range={std['nrmse_range']:.4f} | MAE={std['mae']:.6f} | "
              f"R²={std['r2']:.4f} | Corr={std['corr']:.4f} | Bias={std['bias']:.6f}\n")
    else:
        print(f"{name}: no results; increase RATIO/MAX_WINDOWS or check data.")

# -------- Execute evaluations --------
# [Step 12 / 步骤12] 执行评估配置列表 / Execute all eval configs
for cfg in EVALS:
    print("\n=== Running:", cfg["name"], "===")
    run_eval(cfg)