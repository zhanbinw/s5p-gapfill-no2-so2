# === NO2 LightGBM Gap-Filling Training - Final Version ===
"""
NO2 LightGBM Gap-Filling Training (Final)

中文/English 双语说明 / Bilingual guide

训练一个用于 NO2 缺测填补（gap-filling）的 LightGBM 模型：
- 训练在所有像素上进行，标签仅使用有观测的 NO2 像素
- 与训练/验证/测试年份划分一致，并加载统一标准化器
- 输出模型、性能指标与特征重要性

Train a LightGBM model for NO2 gap-filling:
- Use all pixels for features; supervise only where NO2 is observed
- Follows year splits and uses a shared scaler
- Saves model and reports metrics and feature importance
"""
import os
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

class NO2GapFillingLightGBM:
    """
    [Step 1 / 步骤1] NO2 缺测填补训练器（LightGBM）
    - 组织数据路径、年份划分、特征配置、scaler 路径
    - 统一特征名映射（含 LULC 与别名）
    - 提供训练/验证/评估/重要性与完整实验流程
    """
    def __init__(self, pollutant='NO2', base_path="/content/drive/MyDrive"):
        self.pollutant = pollutant.upper()
        self.base_path = base_path

        # Year-based directories
        # [Step 1.1 / 步骤1.1] 年份划分与目录 / Year splits and directories
        self.train_years = [2019, 2020, 2021]
        self.val_year = 2022
        self.test_year = 2023

        self.train_dirs = [os.path.join(base_path, "Feature_Stacks", f"{self.pollutant}_{year}") for year in self.train_years]
        self.val_dir = os.path.join(base_path, "Feature_Stacks", f"{self.pollutant}_{self.val_year}")
        self.test_dir = os.path.join(base_path, "Feature_Stacks", f"{self.pollutant}_{self.test_year}")

        # Scaler path
        # [Step 1.2 / 步骤1.2] 标准化器与输出目录 / Scaler and outputs
        self.scaler_file = "/content/drive/MyDrive/3DCNN_Pipeline/artifacts/scalers/NO2/meanstd_global_2019_2021.npz"
        self.output_dir = os.path.join(base_path, "Models", f"{self.pollutant}_LightGBM_GapFilling")
        os.makedirs(self.output_dir, exist_ok=True)

        # Feature config
        # [Step 1.3 / 步骤1.3] 特征配置 / Feature config
        self.continuous_features = [
            'dem', 'slope', 'population', 'u10', 'v10', 'blh', 'tp', 't2m', 'sp', 'str', 'ssr', 'ws',
            'lag1', 'neighbor'
        ]
        self.categorical_features = [f'lulc_{i+1:02d}' for i in range(10)]
        self.non_standardized = ['wd_sin', 'wd_cos', 'sin_doy', 'cos_doy', 'weekday_weight']

        # Feature name mapping
        # [Step 1.4 / 步骤1.4] 特征名映射（含 LULC 编码映射）/ Feature name mapping
        self.feature_name_map = {
            'pop': 'population',
            'ssr_clr': 'ssr',
            'no2_lag_1day': 'lag1',
            'no2_neighbor': 'neighbor'
        }
        for i in range(10):
            self.feature_name_map[f'lulc_class_{i}'] = f'lulc_{i+1:02d}'

        # NO2 默认不过滤 y<=0
        # [Step 1.5 / 步骤1.5] 目标过滤与对数变换设置 / Target filter and log transform
        self.filter_nonpositive_target = False
        self.use_log1p = False

        # LightGBM parameters
        # [Step 1.6 / 步骤1.6] 模型超参数 / Model hyperparameters
        self.lgb_params = {
            'objective': 'regression',
            'metric': ['l1','l2'],
            'first_metric_only': True,
            'boosting_type': 'gbdt',
            'num_leaves': 127,
            'learning_rate': 0.03,
            'min_data_in_leaf': 300,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 1,
            'max_bin': 255,
            'num_threads': os.cpu_count() or 8,
            'verbose': -1,
            'random_state': 42,
            'n_estimators': 1000
        }
        self.model = None
        self.scalers = None
        self.feature_order = None
        self.metadata = None
        self.feature_names = None

    def load_scaler(self):
        """
        [Step 2 / 步骤2] 加载标准化器并构建 per-feature 统计
        Load scaler and build per-feature mean/std and metadata.
        """
        if not os.path.exists(self.scaler_file):
            raise FileNotFoundError(f"Scaler file not found: {self.scaler_file}")

        print(f"📊 Loading scaler from: {self.scaler_file}")
        with np.load(self.scaler_file, allow_pickle=True) as data:
            if 'channel_list' in data and 'mean' in data and 'std' in data:
                self.feature_order = data['channel_list'].tolist()

                self.scalers = {}
                mean_dict = data['mean'].item() if isinstance(data['mean'], np.ndarray) and data['mean'].ndim == 0 else data['mean']
                std_dict = data['std'].item() if isinstance(data['std'], np.ndarray) and data['std'].ndim == 0 else data['std']

                for feat_name in self.feature_order:
                    if feat_name in mean_dict and feat_name in std_dict:
                        self.scalers[feat_name] = {
                            'mean': mean_dict[feat_name],
                            'std': std_dict[feat_name],
                            'is_constant': std_dict[feat_name] <= 1e-8
                        }
                    elif feat_name in data['noscale'].tolist():
                        self.scalers[feat_name] = {'is_constant': True}
                    else:
                        print(f"   ⚠️ Scaler data missing for feature: {feat_name}. It will not be scaled.")
                        self.scalers[feat_name] = {'is_constant': True}

                self.metadata = {
                    'method': data['method'].item() if 'method' in data else 'unknown',
                    'mode': data['mode'].item() if 'mode' in data else 'unknown',
                    'pollutant': data['pollutant'].item() if 'pollutant' in data else 'unknown',
                    'train_years': data['train_years'].tolist() if 'train_years' in data else [],
                    'noscale': data['noscale'].tolist() if 'noscale' in data else []
                }
                print(f"✅ Scaler loaded: {self.metadata.get('mode', 'unknown')} mode, {self.metadata.get('pollutant', 'unknown')} for years {self.metadata.get('train_years', [])}")
                print(f"   Loaded {len(self.feature_order)} features from scaler.")
                print(f"   Non-scaled features: {self.metadata.get('noscale', [])}")
            else:
                raise ValueError("Scaler file structure mismatch. Expected 'channel_list', 'mean', 'std' keys.")
        return True

    def apply_scaler(self, X, feature_names):
        """
        [Step 3 / 步骤3] 应用标准化到 2D 特征矩阵 X
        Apply per-feature standardization to 2D array X.
        """
        Xs = X.copy()

        if len(feature_names) != Xs.shape[1]:
            raise ValueError(f"Feature names count ({len(feature_names)}) does not match X columns ({Xs.shape[1]})")

        for i, name in enumerate(feature_names):
            if name in self.scalers:
                scaler_info = self.scalers[name]
                if not scaler_info.get('is_constant', False) and 'mean' in scaler_info and 'std' in scaler_info:
                    mean = scaler_info['mean']
                    std = scaler_info['std']
                    if std > 1e-8:
                        Xs[:, i] = (X[:, i] - mean) / std
                    else:
                        Xs[:, i] = np.where(np.isfinite(X[:, i]), 0.0, np.nan)
                elif name in self.non_standardized:
                    pass
                else:
                    Xs[:, i] = np.where(np.isfinite(X[:, i]), 0.0, np.nan)
            else:
                print(f"   ⚠️ Feature '{name}' not found in scaler. It will not be scaled.")
        return Xs

    def load_training_data_gapfilling(self, sample_size=50000, per_year_files=None, min_valid_ratio=1e-6):
        """
        [Step 4 / 步骤4] 加载训练/验证/测试数据（gap-filling 设置）
        - 提取所有像素的特征；监督仅用有效 NO2 像素
        - 构建特征矩阵、扁平化、缺失填补
        - 返回下采样后的分割数据
        """
        print(f"📊 Loading training data for GAP-FILLING (sample size: {sample_size:,})...")
        print(f"   - Train years: {self.train_years}")
        print(f"   - Val year: {self.val_year}")
        print(f"   - Test year: {self.test_year}")
        print(f"   - Min valid ratio: {min_valid_ratio:.2e}")
        print("💡 This version trains on ALL pixels using auxiliary features!")

        # 收集训练集文件
        train_files_paths = []
        for year_dir in self.train_dirs:
            if os.path.exists(year_dir):
                year_files = sorted([f for f in os.listdir(year_dir) if f.startswith(f"{self.pollutant}_stack_") and f.endswith('.npz')])
                train_files_paths.extend([(os.path.join(year_dir, f), f) for f in year_files])
                print(f"📁 Found {len(year_files)} files in {year_dir}")
            else:
                print(f"⚠️ Training directory not found: {year_dir}")

        # 收集验证集文件
        val_files_paths = []
        if os.path.exists(self.val_dir):
            val_year_files = sorted([f for f in os.listdir(self.val_dir) if f.startswith(f"{self.pollutant}_stack_") and f.endswith('.npz')])
            val_files_paths = [(os.path.join(self.val_dir, f), f) for f in val_year_files]
            print(f"📁 Found {len(val_year_files)} files in {self.val_dir}")
        else:
            print(f"⚠️ Validation directory not found: {self.val_dir}")

        # 收集测试集文件
        test_files_paths = []
        if os.path.exists(self.test_dir):
            test_year_files = sorted([f for f in os.listdir(self.test_dir) if f.startswith(f"{self.pollutant}_stack_") and f.endswith('.npz')])
            test_files_paths = [(os.path.join(self.test_dir, f), f) for f in test_year_files]
            print(f"📁 Found {len(test_year_files)} files in {self.test_dir}")
        else:
            print(f"⚠️ Test directory not found: {self.test_dir}")

        # 处理文件数量限制
        # [Step 4.1 / 步骤4.1] 控制训练文件数量 / Limit processed files
        if per_year_files is None:
            # 使用所有训练文件
            actual_train_files_to_process = train_files_paths
            print("📊 Using ALL available training files for gap-filling training")
        else:
            np.random.seed(42)
            actual_train_files_to_process = np.random.choice(train_files_paths, min(per_year_files * len(self.train_years), len(train_files_paths)), replace=False)

        print(f"📊 Processing {len(actual_train_files_to_process)} train files, {len(val_files_paths)} val files, {len(test_files_paths)} test files...")

        # Helper function to process files with gap-filling logic
        # [Step 4.2 / 步骤4.2] 单文件处理：构建特征、扁平化、缺失填补、选择有效标签
        def _process_files_gapfilling(file_list, is_train=False):
            X_list, y_list = [], []
            processed_count = 0
            skipped_low_valid_ratio = 0
            skipped_no_target_mask = 0
            skipped_error = 0

            for i, (file_path, filename) in enumerate(file_list):
                try:
                    with np.load(file_path, allow_pickle=True, mmap_mode='r') as data:
                        if 'no2_target' not in data or 'no2_mask' not in data:
                            skipped_no_target_mask += 1
                            if i < 10 or (i+1) % 100 == 0:
                                print(f"   ⚠️ {filename}: Missing no2_target or no2_mask, skipped.")
                            continue

                        y = data['no2_target']
                        mask = data['no2_mask']

                        # 数据清理
                        if isinstance(y, np.ndarray) and y.dtype.kind in 'fi':
                            for s in (-9999, -32768):
                                y = np.where(y == s, np.nan, y)
                            y = np.where(np.abs(y) > 1e6, np.nan, y)

                        # 关键修改：使用所有像素进行训练，而不仅仅是有效NO2像素
                        # 这样模型可以学习如何从辅助因子预测缺失的NO2
                        # [Step 4.2.1 / 步骤4.2.1] 预测掩码：全部像素
                        predict_mask = np.ones_like(y, dtype=bool)  # 预测所有像素

                        if not np.any(predict_mask):
                            skipped_low_valid_ratio += 1
                            if i < 10 or (i+1) % 100 == 0:
                                print(f"   ⚠️ {filename}: No pixels to predict, skipped.")
                            continue

                        # 构建特征矩阵
                        # [Step 4.2.2 / 步骤4.2.2] 依据 scaler 顺序与映射装配特征
                        X_features_for_this_file = []
                        for scaler_feat_name in self.feature_order:
                            data_feat_name = None
                            for data_key, scaler_key in self.feature_name_map.items():
                                if scaler_key == scaler_feat_name:
                                    data_feat_name = data_key
                                    break

                            if data_feat_name is None:
                                data_feat_name = scaler_feat_name

                            if data_feat_name in data:
                                X_features_for_this_file.append(data[data_feat_name])
                            else:
                                X_features_for_this_file.append(np.full(y.shape, np.nan, dtype=np.float32))

                        if not X_features_for_this_file:
                            print(f"   ⚠️ No features could be processed for {filename} after mapping, skipping.")
                            continue

                        X_final = np.stack(X_features_for_this_file, axis=0)

                        # 展平并选择所有像素
                        # [Step 4.2.3 / 步骤4.2.3] 扁平化像素 -> 样本
                        X_flat = X_final.reshape(X_final.shape[0], -1).T
                        y_flat = y.flatten()
                        predict_flat = predict_mask.flatten()

                        idx = np.where(predict_flat)[0]
                        if len(idx) == 0:
                            skipped_low_valid_ratio += 1
                            if i < 10 or (i+1) % 100 == 0:
                                print(f"   ⚠️ {filename}: No pixels to predict after flattening, skipped.")
                            continue

                        # 处理缺失特征
                        # [Step 4.2.4 / 步骤4.2.4] 缺失值填补（均值或零）
                        X_predict = X_flat[idx]
                        for j in range(X_predict.shape[1]):
                            col_data = X_predict[:, j]
                            if np.any(np.isfinite(col_data)):
                                mean_val = np.nanmean(col_data)
                                X_predict[:, j] = np.where(np.isfinite(col_data), col_data, mean_val)
                            else:
                                X_predict[:, j] = 0.0

                        # 只使用有NO2观测值的像素作为训练标签
                        # [Step 4.2.5 / 步骤4.2.5] 有效标签筛选（不过滤 y<=0）
                        y_predict = y_flat[idx]
                        valid_y_mask = np.isfinite(y_predict)

                        if np.sum(valid_y_mask) < 100:  # 至少需要100个有效观测
                            skipped_low_valid_ratio += 1
                            if i < 10 or (i+1) % 100 == 0:
                                print(f"   ⚠️ {filename}: Too few valid NO2 observations ({np.sum(valid_y_mask)}), skipped.")
                            continue

                        # 只使用有效NO2观测进行训练
                        # [Step 4.2.6 / 步骤4.2.6] 汇总有效样本
                        X_list.append(X_predict[valid_y_mask])
                        y_list.append(y_predict[valid_y_mask])
                        processed_count += 1

                        if (i+1) % 50 == 0:
                            print(f"   📊 Processed {i+1}/{len(file_list)} files. Current valid samples: {sum(len(x) for x in X_list):,}")
                except Exception as e:
                    skipped_error += 1
                    print(f"   ⚠️ Error processing {filename}: {e}")
                    continue

            print(f"   Summary: Processed {processed_count} files. Skipped {skipped_no_target_mask} (missing target/mask), {skipped_low_valid_ratio} (low valid ratio), {skipped_error} (errors).")
            return X_list, y_list

        # 处理训练集数据
        train_X_list, train_y_list = _process_files_gapfilling(actual_train_files_to_process, is_train=True)

        if len(train_X_list) == 0:
            raise ValueError("No valid training data found after processing all files.")

        # 处理验证集数据
        val_X_list, val_y_list = _process_files_gapfilling(val_files_paths)

        # 处理测试集数据
        test_X_list, test_y_list = _process_files_gapfilling(test_files_paths)

        # 合并数据
        # [Step 4.3 / 步骤4.3] 合并并保证非空
        def _collect(X_list, y_list):
            if len(X_list) == 0:
                return np.empty((0, len(self.feature_order) if self.feature_order else 0)), np.array([])
            return (np.vstack(X_list), np.hstack(y_list))

        X_train, y_train = _collect(train_X_list, train_y_list)
        X_val, y_val = _collect(val_X_list, val_y_list)
        X_test, y_test = _collect(test_X_list, test_y_list)

        # 确保非空
        if len(y_train) == 0:
            raise ValueError("Training data is empty after collection.")
        if len(y_val) == 0:
            print("⚠️ Validation set is empty. Using training data as placeholder.")
            X_val, y_val = X_train, y_train
        if len(y_test) == 0:
            print("⚠️ Test set is empty. Using validation data as placeholder.")
            X_test, y_test = X_val, y_val

        # 下采样
        # [Step 4.4 / 步骤4.4] 控制样本规模（稳定训练）
        def _downsample(Xd, yd, n):
            if len(yd) > n:
                np.random.seed(42)
                idx = np.random.choice(len(yd), n, replace=False)
                return Xd[idx], yd[idx]
            return Xd, yd

        X_train, y_train = _downsample(X_train, y_train, sample_size)
        X_val, y_val = _downsample(X_val, y_val, max(1, sample_size // 3))
        X_test, y_test = _downsample(X_test, y_test, max(1, sample_size // 3))

        self.feature_names = self.feature_order
        print(f"📊 Training set: {len(X_train):,} samples (2019-2021)")
        print(f"📊 Validation set: {len(X_val):,} samples (2022)")
        print(f"📊 Test set: {len(X_test):,} samples (2023)")
        return X_train, X_val, X_test, y_train, y_val, y_test

    def train_model(self, X_train, y_train, X_val, y_val):
        """
        [Step 5 / 步骤5] 训练 LightGBM 模型（早停与验证集）
        Train LightGBM with early stopping on validation set.
        """
        print("🚀 Training LightGBM model for gap-filling...")
        lgb_train = lgb.Dataset(X_train, y_train, feature_name=self.feature_names)
        lgb_eval = lgb.Dataset(X_val, y_val, reference=lgb_train, feature_name=self.feature_names)

        self.model = lgb.train(
            self.lgb_params,
            lgb_train,
            num_boost_round=1000,
            valid_sets=lgb_eval,
            callbacks=[lgb.early_stopping(stopping_rounds=300, verbose=True)]
        )
        print("✅ Model training completed")
        return self.model

    def evaluate_model(self, X_test, y_test):
        """
        [Step 6 / 步骤6] 在测试集评估模型性能
        Evaluate on test set and print metrics.
        """
        print("📊 Evaluating model performance...")
        y_pred = self.model.predict(X_test)

        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)

        print(f"📊 Model Performance:")
        print(f" - RMSE: {rmse:.4f}")
        print(f" - MAE: {mae:.4f}")
        print(f" - R²: {r2:.4f}")
        print(f" - MSE: {mse:.8f}")
        return rmse, mae, r2, mse, y_pred

    def get_feature_importance(self):
        """
        [Step 7 / 步骤7] 计算与保存特征重要性（gain）
        Compute and save feature importance by gain.
        """
        if self.model:
            importance = self.model.feature_importance(importance_type='gain')
            feature_names = self.feature_names

            if feature_names is None or len(feature_names) != len(importance):
                print("⚠️ Feature names not available or mismatch with importance array. Using generic names.")
                feature_names = [f'feature_{i}' for i in range(len(importance))]

            feature_importance_df = pd.DataFrame({
                'feature': feature_names,
                'importance': importance
            }).sort_values(by='importance', ascending=False)

            total_importance = feature_importance_df['importance'].sum()
            feature_importance_df['normalized_importance'] = feature_importance_df['importance'] / total_importance

            print("\n🔍 Top 20 Feature Importance:")
            for i, row in enumerate(feature_importance_df.head(20).itertuples()):
                print(f"{i+1}. {row.feature}: {row.importance:.2e} ({row.normalized_importance:.3f})")

            importance_path = os.path.join(self.output_dir, f"{self.pollutant.lower()}_feat_importance.csv")
            feature_importance_df.to_csv(importance_path, index=False)
            print(f"💾 Feature importance saved: {importance_path}")
            return feature_importance_df
        return None

    def run_gapfilling_experiment(self, sample_size=50000, per_year_files=None):
        """
        [Step 8 / 步骤8] 完整实验流程：加载 -> 数据 -> 标准化 -> 训练 -> 评估 -> 保存
        Full experiment pipeline end-to-end.
        """
        print(f"🚀 NO2 LightGBM Gap-Filling Training")
        print(f"🚀 This version trains on ALL pixels using auxiliary features for true gap-filling!")

        self.load_scaler()

        X_train_raw, X_val_raw, X_test_raw, y_train_raw, y_val_raw, y_test_raw = self.load_training_data_gapfilling(
            sample_size=sample_size, per_year_files=per_year_files
        )

        # Apply scaler to all splits
        X_train = self.apply_scaler(X_train_raw, self.feature_names)
        X_val = self.apply_scaler(X_val_raw, self.feature_names)
        X_test = self.apply_scaler(X_test_raw, self.feature_names)

        model = self.train_model(X_train, y_train_raw, X_val, y_val_raw)
        rmse, mae, r2, mse, y_pred = self.evaluate_model(X_test, y_test_raw)
        feature_importance_df = self.get_feature_importance()

        # Save model
        model_path = os.path.join(self.output_dir, f"{self.pollutant.lower()}_lightgbm_gapfilling_model.txt")
        model.save_model(model_path)
        print(f"💾 Gap-filling model saved: {model_path}")

        results = {
            'rmse': rmse,
            'mae': mae,
            'r2': r2,
            'mse': mse,
            'n_samples': len(y_test_raw)
        }
        print("\n📊 Gap-filling Results Summary:")
        print(f" - RMSE: {results['rmse']:.4f}")
        print(f" - MAE: {results['mae']:.4f}")
        print(f" - R²: {results['r2']:.4f}")
        print(f" - Samples: {results['n_samples']:,}")

        return results, model, feature_importance_df

def main():
    # 创建gap-filling模型
    # [Step 9 / 步骤9] 入口函数：构建模型并运行实验 / Main entry
    model = NO2GapFillingLightGBM(pollutant='NO2')

    # 运行gap-filling实验
    results, best_model, feature_importance = model.run_gapfilling_experiment(
        sample_size=50000,
        per_year_files=None  # 使用所有训练文件
    )

    print("\n--- Gap-filling Experiment Finished ---")
    print(f"R2: {results['r2']:.4f}")
    print(f"Samples: {results['n_samples']:,}")
    print("💡 This model should now be capable of true gap-filling!")

if __name__ == "__main__":
    main()
