#!/usr/bin/env python3
"""
Feature Stack Analyzer
特征栈分析器

用于分析NO2和SO2特征栈的内部结构、维度和内容
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime
import glob
import json
from typing import Dict, List, Tuple, Any

class FeatureStackAnalyzer:
    """特征栈分析器"""
    
    def __init__(self, base_path: str = "/content/drive/MyDrive"):
        """初始化分析器"""
        self.base_path = base_path
        self.feature_stacks_path = os.path.join(base_path, "Feature_Stacks")
        
        print(f"🔍 Feature Stack Analyzer initialized")
        print(f"   - Base path: {self.base_path}")
        print(f"   - Feature stacks path: {self.feature_stacks_path}")
    
    def analyze_single_file(self, file_path: str) -> Dict[str, Any]:
        """分析单个特征栈文件"""
        print(f"\n📊 Analyzing: {os.path.basename(file_path)}")
        
        try:
            # 加载npz文件
            data = np.load(file_path, allow_pickle=True)
            
            analysis = {
                'file_path': file_path,
                'file_size_mb': os.path.getsize(file_path) / (1024 * 1024),
                'arrays': {},
                'metadata': {}
            }
            
            # 分析每个数组
            for key in data.files:
                array = data[key]
                analysis['arrays'][key] = {
                    'shape': array.shape,
                    'dtype': str(array.dtype),
                    'size_mb': array.nbytes / (1024 * 1024),
                    'min': float(np.nanmin(array)) if array.size > 0 else None,
                    'max': float(np.nanmax(array)) if array.size > 0 else None,
                    'mean': float(np.nanmean(array)) if array.size > 0 else None,
                    'nan_count': int(np.isnan(array).sum()) if array.dtype in [np.float32, np.float64] else 0,
                    'nan_ratio': float(np.isnan(array).mean()) if array.dtype in [np.float32, np.float64] else 0
                }
            
            # 提取元数据
            metadata_keys = ['feature_names', 'pollutant', 'season', 'date', 'coverage', 'trainable']
            for key in metadata_keys:
                if key in data.files:
                    analysis['metadata'][key] = data[key].item() if hasattr(data[key], 'item') else data[key]
            
            return analysis
            
        except Exception as e:
            return {'error': str(e), 'file_path': file_path}
    
    def analyze_pollutant(self, pollutant: str, year: int = None) -> Dict[str, Any]:
        """分析特定污染物的特征栈"""
        print(f"\n🔬 Analyzing {pollutant} feature stacks...")
        
        # 构建路径
        if year:
            search_path = os.path.join(self.feature_stacks_path, f"{pollutant}_{year}")
            pattern = f"{pollutant}_{year}/*.npz"
        else:
            search_path = os.path.join(self.feature_stacks_path, f"{pollutant}_*")
            pattern = f"{pollutant}_*/*.npz"
        
        # 查找文件
        files = glob.glob(os.path.join(self.feature_stacks_path, pattern))
        
        if not files:
            return {'error': f'No {pollutant} files found in {search_path}'}
        
        print(f"   Found {len(files)} files")
        
        # 分析前几个文件作为样本
        sample_size = min(5, len(files))
        sample_files = files[:sample_size]
        
        analyses = []
        for file_path in sample_files:
            analysis = self.analyze_single_file(file_path)
            if 'error' not in analysis:
                analyses.append(analysis)
        
        if not analyses:
            return {'error': 'No valid files could be analyzed'}
        
        # 汇总分析结果
        summary = {
            'pollutant': pollutant,
            'total_files': len(files),
            'analyzed_files': len(analyses),
            'sample_files': [os.path.basename(f) for f in sample_files],
            'file_sizes_mb': [a['file_size_mb'] for a in analyses],
            'arrays': {},
            'metadata': {}
        }
        
        # 分析数组结构
        first_analysis = analyses[0]
        for array_name, array_info in first_analysis['arrays'].items():
            summary['arrays'][array_name] = {
                'shape': array_info['shape'],
                'dtype': array_info['dtype'],
                'size_mb': array_info['size_mb']
            }
        
        # 分析元数据
        for key, value in first_analysis['metadata'].items():
            summary['metadata'][key] = value
        
        return summary
    
    def compare_pollutants(self) -> Dict[str, Any]:
        """比较NO2和SO2的特征栈"""
        print(f"\n⚖️ Comparing NO2 and SO2 feature stacks...")
        
        no2_analysis = self.analyze_pollutant('NO2')
        so2_analysis = self.analyze_pollutant('SO2')
        
        comparison = {
            'no2': no2_analysis,
            'so2': so2_analysis,
            'differences': {}
        }
        
        # 比较特征数量
        if 'arrays' in no2_analysis and 'arrays' in so2_analysis:
            no2_features = len([k for k in no2_analysis['arrays'].keys() if k.startswith('feature_names') or k in ['X']])
            so2_features = len([k for k in so2_analysis['arrays'].keys() if k.startswith('feature_names') or k in ['X']])
            
            comparison['differences']['feature_count'] = {
                'no2': no2_features,
                'so2': so2_features,
                'difference': so2_features - no2_features
            }
        
        # 比较文件大小
        if 'file_sizes_mb' in no2_analysis and 'file_sizes_mb' in so2_analysis:
            no2_avg_size = np.mean(no2_analysis['file_sizes_mb'])
            so2_avg_size = np.mean(so2_analysis['file_sizes_mb'])
            
            comparison['differences']['file_size'] = {
                'no2_avg_mb': no2_avg_size,
                'so2_avg_mb': so2_avg_size,
                'size_ratio': so2_avg_size / no2_avg_size if no2_avg_size > 0 else 0
            }
        
        return comparison
    
    def generate_report(self) -> Dict[str, Any]:
        """生成完整的分析报告"""
        print(f"\n📋 Generating comprehensive feature stack analysis report...")
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'base_path': self.base_path,
            'feature_stacks_path': self.feature_stacks_path,
            'no2_analysis': self.analyze_pollutant('NO2'),
            'so2_analysis': self.analyze_pollutant('SO2'),
            'comparison': self.compare_pollutants(),
            'recommendations': []
        }
        
        # 生成建议
        recommendations = []
        
        # 检查特征数量
        if 'differences' in report['comparison'] and 'feature_count' in report['comparison']['differences']:
            diff = report['comparison']['differences']['feature_count']['difference']
            if diff > 0:
                recommendations.append(f"SO2 has {diff} more features than NO2 - this is expected due to climatology features")
            elif diff < 0:
                recommendations.append(f"NO2 has {abs(diff)} more features than SO2 - this may need investigation")
        
        # 检查文件大小
        if 'differences' in report['comparison'] and 'file_size' in report['comparison']['differences']:
            ratio = report['comparison']['differences']['file_size']['size_ratio']
            if ratio > 1.2:
                recommendations.append(f"SO2 files are {ratio:.1f}x larger than NO2 - this is expected due to additional features")
            elif ratio < 0.8:
                recommendations.append(f"NO2 files are {1/ratio:.1f}x larger than SO2 - this may need investigation")
        
        # 检查数据完整性
        for pollutant in ['NO2', 'SO2']:
            analysis = report[f'{pollutant.lower()}_analysis']
            if 'error' not in analysis and 'total_files' in analysis:
                if analysis['total_files'] < 1000:  # 假设每年应该有365个文件
                    recommendations.append(f"{pollutant} has only {analysis['total_files']} files - may be incomplete")
        
        report['recommendations'] = recommendations
        
        return report
    
    def print_summary(self, report: Dict[str, Any]):
        """打印分析摘要"""
        print(f"\n" + "="*80)
        print(f"📊 FEATURE STACK ANALYSIS SUMMARY")
        print(f"="*80)
        
        # NO2分析
        print(f"\n🔵 NO2 Analysis:")
        no2 = report['no2_analysis']
        if 'error' not in no2:
            print(f"   - Total files: {no2['total_files']}")
            print(f"   - Average file size: {np.mean(no2['file_sizes_mb']):.2f} MB")
            if 'arrays' in no2:
                print(f"   - Arrays: {list(no2['arrays'].keys())}")
                if 'X' in no2['arrays']:
                    print(f"   - Feature matrix shape: {no2['arrays']['X']['shape']}")
        else:
            print(f"   - Error: {no2['error']}")
        
        # SO2分析
        print(f"\n🟡 SO2 Analysis:")
        so2 = report['so2_analysis']
        if 'error' not in so2:
            print(f"   - Total files: {so2['total_files']}")
            print(f"   - Average file size: {np.mean(so2['file_sizes_mb']):.2f} MB")
            if 'arrays' in so2:
                print(f"   - Arrays: {list(so2['arrays'].keys())}")
                if 'X' in so2['arrays']:
                    print(f"   - Feature matrix shape: {so2['arrays']['X']['shape']}")
        else:
            print(f"   - Error: {so2['error']}")
        
        # 比较结果
        print(f"\n⚖️ Comparison:")
        if 'differences' in report['comparison']:
            if 'feature_count' in report['comparison']['differences']:
                fc = report['comparison']['differences']['feature_count']
                print(f"   - Feature count: NO2={fc['no2']}, SO2={fc['so2']} (diff: {fc['difference']})")
            
            if 'file_size' in report['comparison']['differences']:
                fs = report['comparison']['differences']['file_size']
                print(f"   - File size: NO2={fs['no2_avg_mb']:.2f}MB, SO2={fs['so2_avg_mb']:.2f}MB (ratio: {fs['size_ratio']:.2f})")
        
        # 建议
        print(f"\n💡 Recommendations:")
        for i, rec in enumerate(report['recommendations'], 1):
            print(f"   {i}. {rec}")
        
        print(f"\n" + "="*80)

def main():
    """主函数"""
    print("🚀 Feature Stack Analyzer")
    print("="*60)
    
    # 初始化分析器
    analyzer = FeatureStackAnalyzer()
    
    # 生成分析报告
    report = analyzer.generate_report()
    
    # 打印摘要
    analyzer.print_summary(report)
    
    # 保存详细报告
    report_file = os.path.join(analyzer.base_path, "feature_stack_analysis_report.json")
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"\n💾 Detailed report saved: {report_file}")
    
    return report

if __name__ == "__main__":
    main()
