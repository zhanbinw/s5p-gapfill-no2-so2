# ==== NO2 3D CNN Masked Validation (random/block + monthly + sensitive-channel masking) ====
"""
NO2 3D CNN Masked Validation Runner

中文/English 双语说明 / Bilingual guide

本脚本对已训练好的 NO2 3D CNN 模型进行遮挡验证（masked validation）：
- 像素随机遮挡或块状遮挡（random/block）
- 可指定月份子集进行评估（monthly filtering）
- 可屏蔽“敏感通道”（如 neighbor）以避免泄漏（sensitive-channel masking）

This script evaluates a trained NO2 3D CNN with masked validation:
- Random pixel masking or block-wise masking
- Optional monthly subset evaluation
- Optional sensitive-channel masking (e.g., neighbor)
"""

import numpy as np, os, torch, re
from numpy.random import default_rng
import torch.nn as nn

# --------- Paths & basic config ---------
# [Step 1 / 步骤1] 基础路径与参数 / Base paths and params
BASE = "/content/drive/MyDrive"
CKPT = f"{BASE}/3DCNN_Pipeline/models/no2_3dcnn_model.pth"
STACK_22 = f"{BASE}/Feature_Stacks/NO2_2022"
STACK_23 = f"{BASE}/Feature_Stacks/NO2_2023"
SCALER   = f"{BASE}/3DCNN_Pipeline/artifacts/scalers/NO2/meanstd_global_2019_2021.npz"

TIME_WINDOW = 7   # [Step 1.1 / 步骤1.1] 时间窗口长度 / temporal window length
H, W = 300, 621
mu_y  = 1.54890004506932e-05
std_y = 3.894585466518877e-05
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# --------- What to evaluate (edit this list) ---------
# [Step 2 / 步骤2] 配置需要评估的场景 / Configure evaluation scenarios
EVALS = [
    # 全年，随机像素遮挡
    {"name":"all_random_pixel", "mode":"random_pixel", "ratio":0.2, "block":32, "months":None, "mask_sensitive":False},
    # 全年，块状遮挡（更难）
    {"name":"all_block32", "mode":"block", "ratio":0.2, "block":32, "months":None, "mask_sensitive":False},
    # 全年，块状遮挡 + 屏蔽敏感通道（如 neighbor）
    {"name":"all_block32_maskNeighbor", "mode":"block", "ratio":0.2, "block":32, "months":None, "mask_sensitive":True},
    # 只评 3 月（示例），可改为 [6,7,8] 表示夏季
    {"name":"Mar_block32", "mode":"block", "ratio":0.2, "block":32, "months":[3], "mask_sensitive":False},
]

# 运行参数
# [Step 2.1 / 步骤2.1] 运行控制参数 / Runtime controls
REPEATS = 3
MAX_WINDOWS = 100          # 每次评估最多处理多少个日窗口（None=全量）
MIN_HOLD = 200

# --------- Model (match training) ----------
# [Step 3 / 步骤3] 定义与训练一致的模型结构 / Model matching training
class NO2_3DCNN_Model(nn.Module):
    def __init__(self, input_channels=29, out_in_01=False):
        super().__init__()
        ch = 32
        self.body = nn.Sequential(
            nn.Conv3d(input_channels, ch, 3, padding=1),
            nn.GroupNorm(8, ch), nn.ReLU(inplace=True),
            nn.Conv3d(ch, ch*2, 3, padding=1),
            nn.GroupNorm(8, ch*2), nn.ReLU(inplace=True),
            nn.Conv3d(ch*2, ch*4, 3, padding=1),
            nn.GroupNorm(8, ch*4), nn.ReLU(inplace=True),
        )
        self.head = nn.Conv3d(ch*4, 1, 1)
    def forward(self, x):              # x: (B,T,C,H,W)
        x = x.permute(0,2,1,3,4)       # -> (B,C,T,H,W)
        return self.head(self.body(x)) # (B,1,T,H,W)

# --------- Scaler & feature order ----------
# [Step 4 / 步骤4] 加载scaler与通道顺序 / Load scaler and feature order
with np.load(SCALER, allow_pickle=True) as sc:
    channel_list = sc['channel_list'].tolist()
    mean_dict = sc['mean'].item() if isinstance(sc['mean'], np.ndarray) and sc['mean'].ndim==0 else sc['mean']
    std_dict  = sc['std'].item()  if isinstance(sc['std'],  np.ndarray) and sc['std'].ndim==0  else sc['std']

# scaler名 -> 文件键
# [Step 4.1 / 步骤4.1] 名称映射（scaler名 -> 栈文件键）/ Name mapping (scaler -> file key)
rev_map = {
    'population':'pop','ssr':'ssr_clr','lag1':'no2_lag_1day','neighbor':'no2_neighbor',
    'lulc_01':'lulc_class_0','lulc_02':'lulc_class_1','lulc_03':'lulc_class_2','lulc_04':'lulc_class_3',
    'lulc_05':'lulc_class_4','lulc_06':'lulc_class_5','lulc_07':'lulc_class_6','lulc_08':'lulc_class_7',
    'lulc_09':'lulc_class_8','lulc_10':'lulc_class_9'
}

# --------- File lists & month map ----------
# [Step 5 / 步骤5] 构建文件列表并解析月份 / Build file lists and month map
files_22 = sorted([os.path.join(STACK_22,f) for f in os.listdir(STACK_22) if f.endswith(".npz")]) if os.path.exists(STACK_22) else []
files_23 = sorted([os.path.join(STACK_23,f) for f in os.listdir(STACK_23) if f.endswith(".npz")])

def filename_month(fp):
    """
    [Step 5.1 / 步骤5.1] 从文件名解析月份（expects NO2_stack_YYYYMMDD.npz）
    Parse month from filename.
    """
    # 解析 like NO2_stack_YYYYMMDD.npz
    m = re.search(r'(\d{8})', os.path.basename(fp))
    if not m: return None
    yyyymmdd = m.group(1)
    return int(yyyymmdd[4:6])

day_months = [filename_month(fp) for fp in files_23]

def filter_day_indices(months):
    """
    [Step 5.2 / 步骤5.2] 依据月份过滤天索引 / Filter days by month list
    """
    if not months:  # None or []
        return list(range(len(files_23)))
    months = set(months)
    return [i for i,mm in enumerate(day_months) if mm in months]

# --------- Build window paths ----------
# [Step 6 / 步骤6] 生成时间窗口对应的文件路径序列 / Build window file paths
def window_paths(day_idx):
    paths=[]
    for t in range(TIME_WINDOW):
        j = day_idx - (TIME_WINDOW-1) + t
        if j < 0:
            k = len(files_22) + j
            paths.append(files_22[k] if 0 <= k < len(files_22) else None)
        elif j < len(files_23):
            paths.append(files_23[j])
        else:
            paths.append(None)
    return paths

# --------- Load one window (T,C,H,W) & last-day y/mask ----------
# [Step 7 / 步骤7] 加载一个时间窗口（含特征标准化、空间对齐）/ Load one temporal window
def load_window(day_idx):
    paths = window_paths(day_idx)
    X_list, y_list, m_list = [], [], []
    for p in paths:
        if p is None or (not os.path.exists(p)):
            X_list.append(np.zeros((len(channel_list),H,W), np.float32))
            y_list.append(np.full((H,W), np.nan, np.float32))
            m_list.append(np.zeros((H,W), dtype=bool))
            continue
        with np.load(p, allow_pickle=True) as data:
            y = data['no2_target'].astype(np.float32)
            m = data['no2_mask'].astype(bool)
            feats=[]
            for name in channel_list:
                key = rev_map.get(name, name)
                if key in data:
                    arr = data[key].astype(np.float32)
                    if arr.shape!=(H,W):
                        buf = np.full((H,W), np.nan, np.float32)
                        hh=min(H,arr.shape[0]); ww=min(W,arr.shape[1])
                        buf[:hh,:ww]=arr[:hh,:ww]; arr=buf
                else:
                    arr = np.full((H,W), np.nan, np.float32)
                arr = np.nan_to_num(arr, nan=0.0)
                mu = mean_dict.get(name,0.0); sd = std_dict.get(name,1.0)
                arr = (arr - mu) / (sd + 1e-12)
                feats.append(arr)
            X = np.stack(feats, axis=0)
            X_list.append(X); y_list.append(y); m_list.append(m)
    X = np.stack(X_list, axis=0)   # (T,C,H,W)
    y = np.stack(y_list, axis=0)   # (T,H,W)
    m = np.stack(m_list, axis=0).astype(bool)
    return X, y, m

# --------- Holdout & metrics ----------
# [Step 8 / 步骤8] 构造 holdout 遮挡与评估指标 / Make holdout and compute metrics
def make_holdout(valid, mode="random_pixel", ratio=0.2, block=32, rng=None):
    if rng is None: rng = default_rng(2025)
    h,w = valid.shape
    hold = np.zeros_like(valid, dtype=bool)
    if mode=="random_pixel":
        idx = np.argwhere(valid)
        if len(idx)==0: return hold
        k = max(1, int(len(idx)*ratio))
        sel = idx[rng.choice(len(idx), k, replace=False)]
        hold[sel[:,0], sel[:,1]] = True
    else:
        target = int(h*w*ratio); covered=0; tries=0
        while covered<target and tries<2000:
            y0 = rng.integers(0, max(1,h-block+1)); x0 = rng.integers(0, max(1,w-block+1))
            patch = np.zeros_like(hold); patch[y0:y0+block, x0:x0+block]=True
            new = patch & valid & (~hold); c=int(new.sum())
            if c>0: hold[new]=True; covered+=c
            tries+=1
    return hold & valid

def compute_metrics(y_true, y_pred):
    """
    [Step 8.1 / 步骤8.1] 计算常用误差与相关性指标 / Compute common regression metrics
    """
    y_true = y_true.astype(np.float64); y_pred = y_pred.astype(np.float64)
    rmse = float(np.sqrt(np.mean((y_true - y_pred)**2)))
    mae  = float(np.mean(np.abs(y_true - y_pred)))
    denom = np.sum((y_true - np.mean(y_true))**2) + 1e-12
    r2 = float(1.0 - np.sum((y_true - y_pred)**2)/denom) if denom>0 else np.nan
    corr = float(np.corrcoef(y_true, y_pred)[0,1]) if (np.std(y_true)>0 and np.std(y_pred)>0) else np.nan
    bias = float(np.mean(y_pred - y_true))
    nrmse_std   = rmse / (np.std(y_true) + 1e-12)
    nrmse_range = rmse / (np.max(y_true)-np.min(y_true) + 1e-12)
    return {"rmse":rmse,"mae":mae,"r2":r2,"corr":corr,"bias":bias,"nrmse_std":nrmse_std,"nrmse_range":nrmse_range}

def print_compact(title, m, n):
    """
    [Step 8.2 / 步骤8.2] 紧凑打印指标摘要 / Compact metric summary printer
    """
    print(f"{title} | n={n:,} | RMSE={m['rmse']:.6f} | NRMSE_std={m['nrmse_std']:.4f} | "
          f"NRMSE_range={m['nrmse_range']:.4f} | MAE={m['mae']:.6f} | R²={m['r2']:.4f} | "
          f"Corr={m['corr']:.4f} | Bias={m['bias']:.6f}")

# 敏感通道索引（如同日 neighbor）
# [Step 9 / 步骤9] 构建敏感通道索引 / Collect sensitive channel indices
def sensitive_channel_indices():
    idxs=[]
    for alias in ['neighbor','no2_neighbor']:
        if alias in channel_list:
            idxs.append(channel_list.index(alias))
    return idxs

# --------- Load model ---------
# [Step 10 / 步骤10] 加载模型权重并置评估模式 / Load checkpoint and eval mode
model = NO2_3DCNN_Model(input_channels=len(channel_list)).to(device)
state = torch.load(CKPT, map_location=device)
state = state.get('model_state_dict', state)
model.load_state_dict(state)
model.eval()

# --------- Runner ---------
# [Step 11 / 步骤11] 运行单个评估配置 / Run one evaluation config
def run_eval(eval_cfg):
    name = eval_cfg["name"]; mode = eval_cfg["mode"]; ratio = eval_cfg["ratio"]; block = eval_cfg["block"]
    months = eval_cfg.get("months")
    mask_sensitive = eval_cfg.get("mask_sensitive", False)

    day_indices = filter_day_indices(months)
    if MAX_WINDOWS is not None:
        day_indices = day_indices[:MAX_WINDOWS]

    rng = default_rng(2026)
    sens_idx = sensitive_channel_indices() if mask_sensitive else []
    runs=[]

    for rep in range(REPEATS):
        ys, ps = [], []
        for di in day_indices:
            X, y, m = load_window(di)
            valid = m[-1]
            if valid.sum()<MIN_HOLD: 
                continue
            hold = make_holdout(valid, mode, ratio, block, rng)
            if hold.sum()<MIN_HOLD:
                continue

            Xt = torch.from_numpy(X).unsqueeze(0).to(device)  # (1,T,C,H,W)
            hold_t = torch.from_numpy(hold).to(device)

            # 训练中 NaN->0 后标准化；评估将被遮挡像素直接置0（所有T、所有C）
            # [Step 11.1 / 步骤11.1] 应用 holdout 遮挡到所有时间与通道 / Apply holdout mask to all T,C
            Xt[:, :, :, hold_t] = 0.0
            # 可选：屏蔽同日敏感通道（如 neighbor），以排除潜在泄漏
            # [Step 11.2 / 步骤11.2] 可选：屏蔽敏感通道 / Optional sensitive channel masking
            for ci in sens_idx:
                Xt[:, :, ci, hold_t] = 0.0

            with torch.no_grad():
                pred = model(Xt)               # (1,1,T,H,W)
                pred_last = pred[:,0,-1]*std_y + mu_y
            y_true = y[-1]; y_pred = pred_last[0].detach().cpu().numpy()

            ys.append(y_true[hold]); ps.append(y_pred[hold])

        if ys:
            y_all = np.concatenate(ys,0); p_all = np.concatenate(ps,0)
            mtr = compute_metrics(y_all, p_all)
            runs.append((mtr, len(y_all)))
            print_compact(f"{name} - run {rep+1} ({mode})", mtr, len(y_all))
        else:
            print(f"{name} - run {rep+1}: no held-out collected")

    if runs:
        mets = [r[0] for r in runs]; ns = [r[1] for r in runs]
        mean = {k: float(np.mean([m[k] for m in mets])) for k in mets[0]}
        std  = {k: float(np.std( [m[k] for m in mets])) for k in mets[0]}
        print_compact(f"{name} - mean", mean, int(np.mean(ns)))
        print(f"(±1σ) RMSE={std['rmse']:.6f} | NRMSE_std={std['nrmse_std']:.4f} | "
              f"NRMSE_range={std['nrmse_range']:.4f} | MAE={std['mae']:.6f} | "
              f"R²={std['r2']:.4f} | Corr={std['corr']:.4f} | Bias={std['bias']:.6f}")
    else:
        print(f"{name}: no results; increase RATIO/MAX_WINDOWS or check data.")

# --------- Execute evaluations ---------
# [Step 12 / 步骤12] 执行评估计划 / Execute evaluation plan
for cfg in EVALS:
    print("\n=== Running:", cfg["name"], "===")
    run_eval(cfg)